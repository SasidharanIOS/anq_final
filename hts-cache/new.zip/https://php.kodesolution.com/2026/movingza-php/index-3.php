<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Movingza - Movers & Packers PHP Template | Home Page 03</title>
  <link href="css/bootstrap.min.css" rel="stylesheet" />
  <link href="css/style.css" rel="stylesheet" />
  <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon" />
  <link rel="icon" href="images/favicon.png" type="image/x-icon" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>
<body>
<div class="page-wrapper">

    <div class="preloader"></div>

    <!-- Back-to-top start -->
    <div class="back-to-top-wrapper">
      <button id="back_to_top" type="button" class="back-to-top-btn">
        <svg width="12" height="7" viewBox="0 0 12 7" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M11 6L6 1L1 6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
        </svg>
      </button>
    </div>
    <!-- Back-to-top start -->

    <!-- Main Header-->
    <header class="main-header header-style-three">
      <div class="outer-box">
        <div class="header-lower anim-fade-move" data-delay="0.25">
          <div class="inner-container">
            <!-- Main box -->
            <div class="main-box">
              <div class="logo-box">
                <div class="logo">
                  <a href="index.php"><img src="images/logo4.png" alt="Logo" /></a>
                </div>
              </div>

            </div>
            <!--Nav Box-->
            <div class="nav-outer">
              <nav class="nav main-menu">
                <ul class="navigation">
  <li class="current dropdown">
    <a href="index.php">Home</a>
    <ul>
      <li><a href="index.php">Home 01</a></li>
      <li><a href="index-2.php">Home 02</a></li>
      <li><a href="index-3.php">Home 03</a></li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">Pages</a>
    <ul>
      <li><a href="page-about.php">About Us</a></li>
      <li class="dropdown"><a href="#">Team</a>
        <ul>
          <li><a href="page-team.php">Team Grid</a></li>
          <li><a href="page-team-details.php">Team Details</a></li>
        </ul>
      </li>
      <li><a href="page-pricing.php">Pricing Plan</a></li>
      <li><a href="page-testimonial.php">Testimonials</a></li>
      <li><a href="page-faq.php">Faq</a></li>
      <li class="dropdown"><a href="#">Shop</a>
        <ul>
          <li><a href="shop-products.php">Products</a></li>
          <li><a href="shop-products-sidebar.php">Products with Sidebar</a></li>
          <li><a href="shop-product-details.php">Product Details</a></li>
          <li><a href="shop-cart.php">Cart</a></li>
          <li><a href="shop-checkout.php">Checkout</a></li>
        </ul>
      </li>
      <li><a href="page-404.php">404</a></li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">Services</a>
    <ul>
      <li><a href="page-services.php">Services Grid</a></li>
      <li><a href="page-service-details.php">Services Details</a></li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">Projects</a>
    <ul>
      <li><a href="page-projects.php">Project Grid</a></li>
      <li><a href="page-project-details.php">Project Details</a></li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">Blog</a>
    <ul>
      <li><a href="news-grid.php">Blog Grid</a></li>
      <li><a href="news-details.php">Blog Details</a></li>
    </ul>
  </li>
  <li class=""><a href="page-contact.php">Contact</a></li>
</ul>
              </nav>
            </div>
            <div class="right-box">
              <button class="ui-btn search-btn">
                <i class="fa-solid fa-magnifying-glass"></i>
              </button>
              <a class="theme-btn btn-style-five" href="page-contact.php">
                <span class="btn-title">Get Appointment </span>
              </a>
              <!--Mobile Navigation Toggler-->
              <div class="mobile-nav-toggler">
                <span></span>
                <span></span>
                <span></span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Mobile Menu  -->
      <div class="mobile-menu">
        <div class="menu-backdrop"></div>
        <!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
        <nav class="menu-box">
          <div class="upper-box">
            <div class="nav-logo">
              <a href="index.php"><img src="images/logo2.png" alt="" /></a>
            </div>
            <div class="close-btn"><i class="icon fa fa-times"></i></div>
          </div>
          <ul class="navigation clearfix">
            <!--Keep This Empty / Menu will come through Javascript-->
          </ul>
          <ul class="contact-list-one">
            <li>
              <i class="icon fa-regular fa-envelope"></i>
              <span class="title">Send Email</span>
              <div class="text"><a href="mailto:needhelp@company.com">needhelp@company.com</a></div>
            </li>
          </ul>
          <ul class="social-links">
            <li>
              <a href="#"><i class="icon fab fa-twitter"></i></a>
            </li>
            <li>
              <a href="#"><i class="icon fab fa-facebook-f"></i></a>
            </li>
            <li>
              <a href="#"><i class="icon fab fa-pinterest-p"></i></a>
            </li>
            <li>
              <a href="#"><i class="icon fab fa-vimeo-v"></i></a>
            </li>
          </ul>
        </nav>
      </div>
      <!-- End Mobile Menu -->

      <!-- Header Search -->
      <div class="search-popup">
        <span class="search-back-drop"></span>
        <button class="close-search"><span class="fa fa-times"></span></button>

        <div class="search-inner">
          <form method="post" action="index.php">
            <div class="form-group">
              <input type="search" name="search-field" value="" placeholder="Search..." required="" />
              <button type="submit"><i class="fa fa-search"></i></button>
            </div>
          </form>
        </div>
      </div>
      <!-- End Header Search -->

      <!-- Sticky Header  -->
      <div class="sticky-header">
        <div class="auto-container">
          <div class="inner-container">
            <!--Logo-->
            <div class="logo">
              <a href="index.php"><img src="images/logo.png" alt=""></a>
            </div>

            <!--Right Col-->
            <div class="nav-outer">
              <!-- Main Menu -->
              <nav class="main-menu">
                <div class="navbar-collapse show collapse clearfix">
                  <ul class="navigation clearfix">
                    <!--Keep This Empty / Menu will come through Javascript-->
                  </ul>
                </div>
              </nav>
              <!-- Main Menu End-->

              <!--Mobile Navigation Toggler-->
              <div class="mobile-nav-toggler">
                <span></span>
                <span></span>
                <span></span>
              </div>
            </div>
            
            <a href="tel:+8801750050088" class="header-phone_box">
              <span class="icon"><i aria-hidden="true" class="fas fa-phone-alt"></i></span>
              <span class="info">
                Call Anytime
                <strong>+8801750050088</strong>
              </span>
            </a>
          </div>
        </div>
      </div>
      <!-- End Sticky Menu -->
    </header>
    <!--End Main Header -->
<!-- start banner-section-three -->
    <section class="banner-section-three">
      <div class="outer-box">
        <div class="shape-2 bounce-y"><img src="images/icons/shape-8.png" alt=""></div>
        <ul class="social-info">
          <li>
            <a href="#">fb</a>
          </li>
          <li>
            <a href="#">tw</a>
          </li>
          <li>
            <a href="#">in</a>
          </li>
          <li>
            <a href="#">yt</a>
          </li>
        </ul>
        <div class="outer-container">
          <div class="shape-1"><img src="images/icons/shape-7.png" alt=""></div>
          <div class="shape-3 bounce-x"><img src="images/icons/shape-9.png" alt=""></div>
          <div class="row">
            <div class="content-column col-xl-8 col-lg-7">
              <div class="inner-column wow fadeInUp" data-wow-delay="200ms">
                <div class="h1 banner-title">Wherever your business moves <span>we're there</span></div>
                <div class="text">At Movingza we are dedicated to making every move simple, smooth, and stress-free. With years of experience in the moving and logistics</div>
                <a href="page-about.php" class="theme-btn btn-style-three">Discover More<i class="fa-light fa-arrow-up-right"></i></a>
              </div>
            </div>
            <div class="col-xl-4 col-lg-5">
              <div class="form-box">
                <div class="inner-box">
                  <div class="h3 title wow fadeInUp" data-wow-delay="200ms">Request a Quote</div>
                  <form action="#">
                    <div class="row gx-3">
                      <div class="col-md-12 wow fadeInUp animated" data-wow-delay=".2s">
                        <div class="form-clt">
                          <input type="text" name="name" id="name" placeholder="Your Name" required="">
                        </div>
                      </div>
                      <div class="col-md-12 wow fadeInUp animated" data-wow-delay=".4s">
                        <div class="form-clt">
                          <input type="email" name="e-mail" id="email" placeholder="Your Email">
                        </div>
                      </div>
                      <div class="col-md-12 wow fadeInUp animated" data-wow-delay=".6s">
                        <div class="form-clt">
                          <select>
                            <option selected="" data-value="I would like to discussed">Move Type</option>
                            <option data-value="Household Move">Household Move</option>
                            <option data-value="Residential Move">Residential Move</option>
                            <option data-value="Project Solutions">Project Solutions</option>
                          </select>
                        </div>
                      </div>
                      <div class="col-md-6 wow fadeInUp animated" data-wow-delay=".8s">
                        <div class="form-clt">
                          <input type="text" name="name" placeholder="From" required="">
                        </div>
                      </div>
                      <div class="col-md-6 wow fadeInUp animated" data-wow-delay=".8s">
                        <div class="form-clt">
                          <input type="text" name="name" placeholder="To" required="">
                        </div>
                      </div>
                      <div class="col-md-12 wow fadeInUp animated" data-wow-delay=".9s">
                        <button class="theme-btn btn-style-four" type="submit">Check Availability</button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <video autoplay="" muted="" loop="" playsinline="" class="bg-video">
        <source src="images/resource/banner3-1.mp4" type="video/mp4">
      </video>
    </section>
    <!-- end banner-section-three -->
<!-- Clients Section One-->
    <section class="clients-section">
      <div class="outer-container wow fadeInUp" data-wow-delay="400ms">
        <div class="outer-box">
          <div class="swiper-container">
            <div class="swiper clients-swiper-one pb-0">
              <div class="swiper-wrapper">
                <div class="swiper-slide">
                  <div class="client-block">
                    <div class="inner-box">
                      <div class="image-box">
                        <figure class="image">
                          <img src="images/resource/client1-2.png" alt="Image">
                          <img src="images/resource/client1-1.png" alt="Image">
                        </figure>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="swiper-slide">
                  <div class="client-block">
                    <div class="inner-box">
                      <div class="image-box">
                        <figure class="image">
                          <img src="images/resource/client2-2.png" alt="Image">
                          <img src="images/resource/client2-1.png" alt="Image">
                        </figure>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="swiper-slide">
                  <div class="client-block">
                    <div class="inner-box">
                      <div class="image-box">
                        <figure class="image">
                          <img src="images/resource/client3-2.png" alt="Image">
                          <img src="images/resource/client3-1.png" alt="Image">
                        </figure>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="swiper-slide">
                  <div class="client-block">
                    <div class="inner-box">
                      <div class="image-box">
                        <figure class="image">
                          <img src="images/resource/client4-2.png" alt="Image">
                          <img src="images/resource/client4-1.png" alt="Image">
                        </figure>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="swiper-slide">
                  <div class="client-block">
                    <div class="inner-box">
                      <div class="image-box">
                        <figure class="image">
                          <img src="images/resource/client5-2.png" alt="Image">
                          <img src="images/resource/client5-1.png" alt="Image">
                        </figure>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="swiper-slide">
                  <div class="client-block">
                    <div class="inner-box">
                      <div class="image-box">
                        <figure class="image">
                          <img src="images/resource/client6-2.png" alt="Image">
                          <img src="images/resource/client6-1.png" alt="Image">
                        </figure>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="swiper-slide">
                  <div class="client-block">
                    <div class="inner-box">
                      <div class="image-box">
                        <figure class="image">
                          <img src="images/resource/client1-2.png" alt="Image">
                          <img src="images/resource/client1-1.png" alt="Image">
                        </figure>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="swiper-slide">
                  <div class="client-block">
                    <div class="inner-box">
                      <div class="image-box">
                        <figure class="image">
                          <img src="images/resource/client2-2.png" alt="Image">
                          <img src="images/resource/client2-1.png" alt="Image">
                        </figure>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="swiper-slide">
                  <div class="client-block">
                    <div class="inner-box">
                      <div class="image-box">
                        <figure class="image">
                          <img src="images/resource/client3-2.png" alt="Image">
                          <img src="images/resource/client3-1.png" alt="Image">
                        </figure>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="swiper-slide">
                  <div class="client-block">
                    <div class="inner-box">
                      <div class="image-box">
                        <figure class="image">
                          <img src="images/resource/client4-2.png" alt="Image">
                          <img src="images/resource/client4-1.png" alt="Image">
                        </figure>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="swiper-slide">
                  <div class="client-block">
                    <div class="inner-box">
                      <div class="image-box">
                        <figure class="image">
                          <img src="images/resource/client5-2.png" alt="Image">
                          <img src="images/resource/client5-1.png" alt="Image">
                        </figure>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="swiper-slide">
                  <div class="client-block">
                    <div class="inner-box">
                      <div class="image-box">
                        <figure class="image">
                          <img src="images/resource/client6-2.png" alt="Image">
                          <img src="images/resource/client6-1.png" alt="Image">
                        </figure>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--End Clients Section One -->
<!-- start about-section-three -->
    <section class="about-section-three">
      <div class="auto-container">
        <div class="row">
          <div class="image-column col-xl-6">
            <div class="inner-column">
              <div class="images-box">
                <div class="icon-box">
                  <div class="icon-one"><img src="images/icons/about3-1.png" alt=""></div>
                  <div class="icon-two"><img src="images/icons/about3-2.png" alt=""></div>
                </div>
                <div class="image wow fadeInUp" data-wow-delay="200ms"><img src="images/resource/about3-1.jpg" alt=""></div>
                <div class="image two wow fadeInUp" data-wow-delay="400ms"><img src="images/resource/about3-2.jpg" alt=""></div>
              </div>
            </div>
          </div>
          <div class="content-column col-xl-6 col-lg-10 wow fadeInUp" data-wow-delay="600ms">
            <div class="inner-column">
              <div class="sec-title">
                <div class="h6 sub-title">Who We Are</div>
                <div class="h2 title">More than movers we're your <span>moving partners</span></div>
                <div class="text">Project Windows and Doors is an Australian-owned company ur adipic sed do bismuthate provides high-quality products and expertise for windows and doors needs. Whether you are a builder or a</div>
              </div>
              <div class="content-box">
                <div class="inner-box">
                  <div class="content">
                    <ul class="list-style-three">
                      <li>
                        <i class="icon fa-solid fa-check"></i>
                        <span>Safe & Secure Handling</span>
                      </li>
                      <li>
                        <i class="icon fa-solid fa-check"></i>
                        <span>Affordable Pricing</span>
                      </li>
                      <li>
                        <i class="icon fa-solid fa-check"></i>
                        <span>Experienced Professionals</span>
                      </li>
                      <li>
                        <i class="icon fa-solid fa-check"></i>
                        <span>Modern Equipment</span>
                      </li>
                    </ul>
                    <a href="page-about.php" class="theme-btn btn-style-three">More About Us<i class="fa-light fa-arrow-up-right"></i></a>
                  </div>
                  <div class="image">
                    <img src="images/resource/about3-3.jpg" alt="">
                    <a class="video" href="https://www.youtube.com/watch?v=hddwAIXbKZo" data-fancybox="gallery" data-caption="">
                      <i class="fa-solid fa-play"></i>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- end about-section-three -->
<!-- start service-section-four -->
    <section class="services-section-four">
      <div class="outer-box">
        <div class="auto-container">
          <div class="sec-title text-center style-two">
            <div class="h6 sub-title wow fadeInUp" data-wow-delay="200ms">What We Provide</div>
            <div class="h2 title wow fadeInUp" data-wow-delay="400ms">What We are Offering to <br>Our Potential <span>Client</span></div>
          </div>
          <div class="row">
            <div class="service-block-five col-xl-3 col-md-6 wow fadeInUp" data-wow-delay="200ms">
              <div class="inner-block">
                <div class="icon"><img src="images/icons/service5-1.png" alt=""></div>
                <div class="h4 title"><a href="page-service-details.php">Furniture Disassembly & Assembly</a></div>
                <div class="image-box"><div class="image one"><img src="images/resource/service5-1.jpg" alt=""></div></div>
              </div>
            </div>
            <div class="service-block-five col-xl-3 col-md-6 wow fadeInUp" data-wow-delay="400ms">
              <div class="inner-block style-two">
                <div class="icon"><img src="images/icons/service5-2.png" alt=""></div>
                <div class="h4 title"><a href="page-service-details.php">Local & Long-Distance Moving</a></div>
                <div class="image-box"><div class="image two"><img src="images/resource/service5-2.jpg" alt=""></div></div>
              </div>
            </div>
            <div class="service-block-five col-xl-3 col-md-6 wow fadeInUp" data-wow-delay="600ms">
              <div class="inner-block">
                <div class="icon"><img src="images/icons/service5-3.png" alt=""></div>
                <div class="h4 title"><a href="page-service-details.php">Packing & Unpacking Services</a></div>
                <div class="image-box"><div class="image three"><img src="images/resource/service5-3.jpg" alt=""></div></div>
              </div>
            </div>
            <div class="service-block-five col-xl-3 col-md-6 wow fadeInUp" data-wow-delay="800ms">
              <div class="inner-block style-two">
                <div class="icon"><img src="images/icons/service5-4.png" alt=""></div>
                <div class="h4 title"><a href="page-service-details.php">Commercial & Office Moving</a></div>
                <div class="image-box"><div class="image four"><img src="images/resource/service5-4.jpg" alt=""></div></div>
              </div>
            </div>
            <div class="btn-box text-center col-lg-12 wow fadeInUp" data-wow-delay="800ms">
              <a href="page-services.php" class="theme-btn btn-style-three">View All Services<i class="fa-light fa-arrow-up-right"></i></a>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- end service-section-four -->
<!-- start working-section-three -->
    <section class="working-section-three">
      <div class="auto-container">
        <div class="row">
          <div class="content-column col-xl-5">
            <div class="inner-column wow fadeInUp" data-wow-delay="200ms">
              <div class="sec-title">
                <div class="h6 sub-title">How It  Works</div>
                <div class="h2 title">Simple Process for <br>a <span>Smooth Move</span></div>
              </div>
              <div class="images-box">
                <div class="image"><img src="images/resource/work3-1.jpg" alt=""></div>
                <a class="video" href="https://www.youtube.com/watch?v=hddwAIXbKZo" data-fancybox="gallery" data-caption="">
                  <i class="fa-solid fa-play"></i>
                </a>
              </div>
            </div>
          </div>
          <div class="working-column col-xl-7">
            <div class="inner-column wow fadeInUp" data-wow-delay="400ms">
              <div class="working-block-three">
                <div class="inner-block">
                  <div class="step">
                    <div class="working-count"><span>01</span></div>
                  </div>
                  <div class="content">
                  <div class="h4 working-title">Request a Quote</div>
                  <div class="text">Tell us about your move—location, size, and preferred date. We'll provide a fast, transparent quote with no hidden fees</div>
                  </div>
                </div>
              </div>
              <div class="working-block-three">
                <div class="inner-block">
                  <div class="step">
                    <div class="working-count"><span>02</span></div>
                  </div>
                  <div class="content">
                  <div class="h4 working-title">Packing & Preparation</div>
                  <div class="text">Our trained movers carefully pack and protect your belongings using high-quality materials, or we can work with items</div>
                  </div>
                </div>
              </div>
              <div class="working-block-three">
                <div class="inner-block">
                  <div class="step">
                    <div class="working-count"><span>03</span></div>
                  </div>
                  <div class="content">
                  <div class="h4 working-title">Safe Transportation</div>
                  <div class="text">We transport your items securely and efficiently, ensuring everything arrives on time and in perfect condition</div>
                  </div>
                </div>
              </div>
              <div class="working-block-three">
                <div class="inner-block">
                  <div class="step">
                    <div class="working-count"><span>04</span></div>
                  </div>
                  <div class="content mb-0">
                  <div class="h4 working-title">Unloading & Setup</div>
                  <div class="text">We unload, place items where you want them, and can even help with unpacking—so you can settle in stress-free</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- end working-section-three -->
<!-- start project-section-two -->
    <section class="project-section-two">
      <div class="outer-container">
        <div class="auto-container">
          <div class="sec-title-box">
            <div class="sec-title light">
              <div class="h6 sub-title">Latest Projects</div>
              <div class="h2 title">Our Most Recent Moving Success <span>Stories</span></div>
            </div>
            <a href="page-projects.php" class="theme-btn btn-style-three">View All Projects<i class="fa-light fa-arrow-up-right"></i></a>
          </div>
        </div>
        <div class="outer-box">
          <div class="project-block-two active wow fadeInUp" data-wow-delay="200ms">
            <div class="inner-block">
              <div class="image"><img src="images/resource/project3-1.jpg" alt=""></div>
              <div class="content">
                <div class="title-box"><div class="h4 title"><a href="page-project-details.php">Long-Distance Household Move</a></div>
                  <div class="excerpt">Planning a long-distance household move can feel over whelming but with the right team, it becomes a smooth </div>
                </div>
                <div class="btn-view-details">
                  <a href="page-project-details.php"><i class="fa-solid fa-arrow-right"></i></a>
                </div>
              </div>
            </div>
          </div>
          <div class="project-block-two wow fadeInUp" data-wow-delay="400ms">
            <div class="inner-block">
              <div class="image"><img src="images/resource/project3-2.jpg" alt=""></div>
              <div class="content">
                <div class="title-box"><div class="h4 title"><a href="page-project-details.php">Apartment-to-House Moving Service</a></div>
                  <div class="excerpt">Planning a long-distance household move can feel over whelming but with the right team, it becomes a smooth </div>
                </div>
                <div class="btn-view-details">
                  <a href="page-project-details.php"><i class="fa-solid fa-arrow-right"></i></a>
                </div>
              </div>
            </div>
          </div>
          <div class="project-block-two wow fadeInUp" data-wow-delay="600ms">
            <div class="inner-block">
              <div class="image"><img src="images/resource/project3-3.jpg" alt=""></div>
              <div class="content">
                <div class="title-box"><div class="h4 title"><a href="page-project-details.php">Full Office Relocation Project Solutions</a></div>
                  <div class="excerpt">Planning a long-distance household move can feel over whelming but with the right team, it becomes a smooth </div>
                </div>
                <div class="btn-view-details">
                  <a href="page-project-details.php"><i class="fa-solid fa-arrow-right"></i></a>
                </div>
              </div>
            </div>
          </div>
          <div class="project-block-two wow fadeInUp" data-wow-delay="800ms">
            <div class="inner-block">
              <div class="image"><img src="images/resource/project3-4.jpg" alt=""></div>
              <div class="content">
                <div class="title-box"><div class="h4 title"><a href="page-project-details.php">Complete Residential Home Move</a></div>
                  <div class="excerpt">Planning a long-distance household move can feel over whelming but with the right team, it becomes a smooth </div>
                </div>
                <div class="btn-view-details">
                  <a href="page-project-details.php"><i class="fa-solid fa-arrow-right"></i></a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- end project-section-two -->
<!-- start pricing-section-two -->
    <section class="pricing-section-two">
      <div class="auto-container">
        <div class="sec-title text-center">
          <div class="h6 sub-title">Pricing Plan</div>
          <div class="h2 title">Select a Plan According to <br>Your <span>Requirements</span></div>
        </div>
        <div class="default-tabs tabs-box mb-0">
          <!-- Tab Btns -->
          <div class="tab-btns tab-buttons wow fadeInUp" data-wow-delay="300ms">
            <button data-tab="#prod-monthly" class="tab-btn one active-btn">Monthly</button>
            <span></span>
            <button data-tab="#prod-yearly" class="tab-btn">Yearly</button>
          </div>

          <!-- Tabs Container -->
          <div class="tabs-content">

            <!-- Tab -->
            <div class="tab active-tab" id="prod-monthly">
              <div class="tab-inner-content">
                <div class="pricing-outer">
                  <div class="row gx-4">
                    <div class="pricing-block-two col-xl-4 col-md-6 wow fadeInUp" data-wow-delay="200ms">
                      <div class="inner-block">
                        <div class="catagory">Free</div>
                        <div class="price-box"><span>$0</span>/month</div>
                        <div class="text">Organize your daily task for free</div>
                        <ul class="list-style-one">
                          <li>
                            <i class="icon fa-solid fa-check"></i>
                            <span>1 Moving Truck (Up to 14 ft)</span>
                          </li>
                          <li>
                            <i class="icon fa-solid fa-check"></i>
                            <span>Professional Movers</span>
                          </li>
                          <li>
                            <i class="icon fa-solid fa-check"></i>
                            <span>Basic Loading & Unloading</span>
                          </li>
                          <li>
                            <i class="icon fa-solid fa-check"></i>
                            <span>Up to 2 Hours of Service</span>
                          </li>
                          <li>
                            <i class="icon fa-solid fa-check"></i>
                            <span>Full Packing Service</span>
                          </li>
                        </ul>
                        <a href="page-pricing.php" class="theme-btn btn-style-five">Join this plan</a>
                      </div>
                    </div>
                    <div class="pricing-block-two col-xl-4 col-md-6 wow fadeInUp" data-wow-delay="400ms">
                      <div class="inner-block active">
                        <div class="type">Popular</div>
                        <div class="catagory">Pro</div>
                        <div class="price-box"><span>$64</span>/month</div>
                        <div class="text">Organize your daily task for free</div>
                        <ul class="list-style-one">
                          <li>
                            <i class="icon fa-solid fa-check"></i>
                            <span>1 Moving Truck (Up to 14 ft)</span>
                          </li>
                          <li>
                            <i class="icon fa-solid fa-check"></i>
                            <span>Professional Movers</span>
                          </li>
                          <li>
                            <i class="icon fa-solid fa-check"></i>
                            <span>Basic Loading & Unloading</span>
                          </li>
                          <li>
                            <i class="icon fa-solid fa-check"></i>
                            <span>Up to 2 Hours of Service</span>
                          </li>
                          <li>
                            <i class="icon fa-solid fa-check"></i>
                            <span>Full Packing Service</span>
                          </li>
                        </ul>
                        <a href="page-pricing.php" class="theme-btn btn-style-five">Join this plan</a>
                      </div>
                    </div>
                    <div class="pricing-block-two col-xl-4 col-md-6 wow fadeInUp" data-wow-delay="600ms">
                      <div class="inner-block">
                        <div class="catagory">Business</div>
                        <div class="price-box"><span>$149</span>/month</div>
                        <div class="text">You can use over 20 basic features</div>
                        <ul class="list-style-one">
                          <li>
                            <i class="icon fa-solid fa-check"></i>
                            <span>1 Moving Truck (Up to 14 ft)</span>
                          </li>
                          <li>
                            <i class="icon fa-solid fa-check"></i>
                            <span>Professional Movers</span>
                          </li>
                          <li>
                            <i class="icon fa-solid fa-check"></i>
                            <span>Basic Loading & Unloading</span>
                          </li>
                          <li>
                            <i class="icon fa-solid fa-check"></i>
                            <span>Up to 2 Hours of Service</span>
                          </li>
                          <li>
                            <i class="icon fa-solid fa-check"></i>
                            <span>Full Packing Service</span>
                          </li>
                        </ul>
                        <a href="page-pricing.php" class="theme-btn btn-style-five">Join this plan</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Tab -->
            <div class="tab" id="prod-yearly">
              <div class="tab-inner-content">
                <div class="pricing-outer">
                  <div class="row gx-4">
                    <div class="pricing-block-two col-xl-4 col-md-6">
                      <div class="inner-block">
                        <div class="catagory">Free</div>
                        <div class="price-box"><span>$0</span>/year</div>
                        <div class="text">Organize your daily task for free</div>
                        <ul class="list-style-one">
                          <li>
                            <i class="icon fa-solid fa-check"></i>
                            <span>1 Moving Truck (Up to 14 ft)</span>
                          </li>
                          <li>
                            <i class="icon fa-solid fa-check"></i>
                            <span>Professional Movers</span>
                          </li>
                          <li>
                            <i class="icon fa-solid fa-check"></i>
                            <span>Basic Loading & Unloading</span>
                          </li>
                          <li>
                            <i class="icon fa-solid fa-check"></i>
                            <span>Up to 2 Hours of Service</span>
                          </li>
                          <li>
                            <i class="icon fa-solid fa-check"></i>
                            <span>Full Packing Service</span>
                          </li>
                        </ul>
                        <a href="page-pricing.php" class="theme-btn btn-style-five">Join this plan</a>
                      </div>
                    </div>
                    <div class="pricing-block-two col-xl-4 col-md-6">
                      <div class="inner-block active">
                        <div class="type">Popular</div>
                        <div class="catagory">Pro</div>
                        <div class="price-box"><span>$700</span>/year</div>
                        <div class="text">Organize your daily task for free</div>
                        <ul class="list-style-one">
                          <li>
                            <i class="icon fa-solid fa-check"></i>
                            <span>1 Moving Truck (Up to 14 ft)</span>
                          </li>
                          <li>
                            <i class="icon fa-solid fa-check"></i>
                            <span>Professional Movers</span>
                          </li>
                          <li>
                            <i class="icon fa-solid fa-check"></i>
                            <span>Basic Loading & Unloading</span>
                          </li>
                          <li>
                            <i class="icon fa-solid fa-check"></i>
                            <span>Up to 2 Hours of Service</span>
                          </li>
                          <li>
                            <i class="icon fa-solid fa-check"></i>
                            <span>Full Packing Service</span>
                          </li>
                        </ul>
                        <a href="page-pricing.php" class="theme-btn btn-style-five">Join this plan</a>
                      </div>
                    </div>
                    <div class="pricing-block-two col-xl-4 col-md-6">
                      <div class="inner-block">
                        <div class="catagory">Business</div>
                        <div class="price-box"><span>$1700</span>/year</div>
                        <div class="text">You can use over 20 basic features</div>
                        <ul class="list-style-one">
                          <li>
                            <i class="icon fa-solid fa-check"></i>
                            <span>1 Moving Truck (Up to 14 ft)</span>
                          </li>
                          <li>
                            <i class="icon fa-solid fa-check"></i>
                            <span>Professional Movers</span>
                          </li>
                          <li>
                            <i class="icon fa-solid fa-check"></i>
                            <span>Basic Loading & Unloading</span>
                          </li>
                          <li>
                            <i class="icon fa-solid fa-check"></i>
                            <span>Up to 2 Hours of Service</span>
                          </li>
                          <li>
                            <i class="icon fa-solid fa-check"></i>
                            <span>Full Packing Service</span>
                          </li>
                        </ul>
                        <a href="page-pricing.php" class="theme-btn btn-style-five">Join this plan</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </section>
    <!-- end pricing-section-two -->
<!-- start team-section-three -->
    <section class="team-section-three">
      <div class="outer-box">
        <div class="auto-container">
          <div class="sec-title-box">
            <div class="sec-title style-two">
              <div class="h6 sub-title">Our Experts</div>
              <div class="h2 title">Professionals You Can Trust With <span>Your Move</span></div>
            </div>
            <a href="page-team.php" class="theme-btn btn-style-three">View All Experts<i class="fa-light fa-arrow-up-right"></i></a>
          </div>
          <div class="row gx-4">
            <div class="team-block-three col-xl-3 col-md-6 wow fadeInUp" data-wow-delay="200ms">
              <div class="inner-block">
                <div class="socials">
                  <i class="fa fa-plus"></i>
                  <ul class="social-links">
                    <li><a aria-label="facebook" href="#"><i class="fab fa-facebook"></i></a></li>
                    <li><a aria-label="twitter" href="#"><i class="fab fa-twitter"></i></a></li>
                    <li><a aria-label="instagram" href="#"><i class="fab fa-instagram"></i></a></li>
                  </ul>
                </div>
                <div class="images-box">
                  <div class="shape-1"><img src="images/icons/shape-10.png" alt=""></div>
                  <div class="image">
                    <img src="images/resource/team3-1.jpg" alt="">
                    <img src="images/resource/team3-1.jpg" alt="">
                  </div>
                </div>
                <div class="content-box">
                  <div class="designation">Ceo-Founder</div>
                  <div class="h4 title"><a href="page-team-details.php">Esther Howard</a></div>
                </div>
              </div>
            </div>
            <div class="team-block-three col-xl-3 col-md-6 wow fadeInUp" data-wow-delay="400ms">
              <div class="inner-block">
                <div class="socials">
                  <i class="fa fa-plus"></i>
                  <ul class="social-links">
                    <li><a aria-label="facebook" href="#"><i class="fab fa-facebook"></i></a></li>
                    <li><a aria-label="twitter" href="#"><i class="fab fa-twitter"></i></a></li>
                    <li><a aria-label="instagram" href="#"><i class="fab fa-instagram"></i></a></li>
                  </ul>
                </div>
                <div class="images-box">
                  <div class="shape-1"><img src="images/icons/shape-10.png" alt=""></div>
                  <div class="image">
                    <img src="images/resource/team3-2.jpg" alt="">
                    <img src="images/resource/team3-2.jpg" alt="">
                  </div>
                </div>
                <div class="content-box">
                  <div class="designation">Founder-in-Lead</div>
                  <div class="h4 title"><a href="page-team-details.php">Leslie Alexander</a></div>
                </div>
              </div>
            </div>
            <div class="team-block-three col-xl-3 col-md-6 wow fadeInUp" data-wow-delay="600ms">
              <div class="inner-block">
                <div class="socials">
                  <i class="fa fa-plus"></i>
                  <ul class="social-links">
                    <li><a aria-label="facebook" href="#"><i class="fab fa-facebook"></i></a></li>
                    <li><a aria-label="twitter" href="#"><i class="fab fa-twitter"></i></a></li>
                    <li><a aria-label="instagram" href="#"><i class="fab fa-instagram"></i></a></li>
                  </ul>
                </div>
                <div class="images-box">
                  <div class="shape-1"><img src="images/icons/shape-10.png" alt=""></div>
                  <div class="image">
                    <img src="images/resource/team3-3.jpg" alt="">
                    <img src="images/resource/team3-3.jpg" alt="">
                  </div>
                </div>
                <div class="content-box">
                  <div class="designation">Strategic Lead</div>
                  <div class="h4 title"><a href="page-team-details.php">Jenny Wilson</a></div>
                </div>
              </div>
            </div>
            <div class="team-block-three col-xl-3 col-md-6 wow fadeInUp" data-wow-delay="800ms">
              <div class="inner-block">
                <div class="socials">
                  <i class="fa fa-plus"></i>
                  <ul class="social-links">
                    <li><a aria-label="facebook" href="#"><i class="fab fa-facebook"></i></a></li>
                    <li><a aria-label="twitter" href="#"><i class="fab fa-twitter"></i></a></li>
                    <li><a aria-label="instagram" href="#"><i class="fab fa-instagram"></i></a></li>
                  </ul>
                </div>
                <div class="images-box">
                  <div class="shape-1"><img src="images/icons/shape-10.png" alt=""></div>
                  <div class="image">
                    <img src="images/resource/team3-4.jpg" alt="">
                    <img src="images/resource/team3-4.jpg" alt="">
                  </div>
                </div>
                <div class="content-box">
                  <div class="designation">Executive Officer</div>
                  <div class="h4 title"><a href="page-team-details.php">Courtney Henry</a></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- end team-section-three -->
<!-- start faq-section-three -->
    <section class="faq-section-three">
      <div class="auto-container">
        <div class="sec-title text-center">
          <div class="h6 sub-title">Frequently Asked Question</div>
          <div class="h2 title">Have Questions in Your Mind? <br>Get the <span>Answers Now</span></div>
        </div>

        <div class="default-tabs tabs-box mb-0">
          <!-- Tab Btns -->
          <div class="tab-btns tab-buttons wow fadeInUp" data-wow-delay="300ms">
            <button data-tab="#prod-general" class="tab-btn">General</button>
            <button data-tab="#prod-support" class="tab-btn active-btn">Support</button>
            <button data-tab="#prod-moving" class="tab-btn">About Moving</button>
          </div>

          <!-- Tabs Container -->
          <div class="tabs-content">

            <!-- Tab -->
            <div class="tab" id="prod-general">
              <div class="tab-inner-content">
                <div class="row">
                  <div class="faq-column col-lg-12">
                    <div class="inner-column">
                      <div class="faq-box">
                        <div class="inner-box">
                          <ul class="accordion-box">
                            <!--Block-->
                            <li class="accordion block">
                              <div class="acc-btn">How far in advance should I schedule my move?
                                <i class="icon fa-solid fa-plus"></i>
                              </div>
                              <div class="acc-content">
                                <div class="content">
                                  <div class="text">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a moreIt is a long established fact that a reader </div>
                                </div>
                              </div>
                            </li>
                            <!--Block-->
                            <li class="accordion block active-block">
                              <div class="acc-btn active">What's the difference between a binding and non-binding estimate?
                                <i class="icon fa-solid fa-plus"></i>
                              </div>
                              <div class="acc-content current">
                                <div class="content">
                                  <div class="text">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a moreIt is a long established fact that a reader </div>
                                </div>
                              </div>
                            </li>
                            <!--Block-->
                            <li class="accordion block">
                              <div class="acc-btn">Do movers need to do an in-person survey to give an estimate?
                                <i class="icon fa-solid fa-plus"></i>
                              </div>
                              <div class="acc-content">
                                <div class="content">
                                  <div class="text">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a moreIt is a long established fact that a reader </div>
                                </div>
                              </div>
                            </li>
                            <!--Block-->
                            <li class="accordion block">
                              <div class="acc-btn">What happens if my new home isn't ready on moving day?
                                <i class="icon fa-solid fa-plus"></i>
                              </div>
                              <div class="acc-content">
                                <div class="content">
                                  <div class="text">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a moreIt is a long established fact that a reader </div>
                                </div>
                              </div>
                            </li>
                            <!--Block-->
                            <li class="accordion block">
                              <div class="acc-btn">What should I do if my belongings are damaged or lost?
                                <i class="icon fa-solid fa-plus"></i>
                              </div>
                              <div class="acc-content">
                                <div class="content">
                                  <div class="text">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a moreIt is a long established fact that a reader </div>
                                </div>
                              </div>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Tab -->
            <div class="tab active-tab" id="prod-support">
              <div class="tab-inner-content">
                <div class="row">
                  <div class="faq-column col-lg-12">
                    <div class="inner-column wow fadeInUp" data-wow-delay="200ms">
                      <div class="faq-box">
                        <div class="inner-box">
                          <ul class="accordion-box">
                            <!--Block-->
                            <li class="accordion block">
                              <div class="acc-btn">How far in advance should I schedule my move?
                                <i class="icon fa-solid fa-plus"></i>
                              </div>
                              <div class="acc-content">
                                <div class="content">
                                  <div class="text">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a moreIt is a long established fact that a reader </div>
                                </div>
                              </div>
                            </li>
                            <!--Block-->
                            <li class="accordion block active-block">
                              <div class="acc-btn active">What's the difference between a binding and non-binding estimate?
                                <i class="icon fa-solid fa-plus"></i>
                              </div>
                              <div class="acc-content current">
                                <div class="content">
                                  <div class="text">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a moreIt is a long established fact that a reader </div>
                                </div>
                              </div>
                            </li>
                            <!--Block-->
                            <li class="accordion block">
                              <div class="acc-btn">Do movers need to do an in-person survey to give an estimate?
                                <i class="icon fa-solid fa-plus"></i>
                              </div>
                              <div class="acc-content">
                                <div class="content">
                                  <div class="text">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a moreIt is a long established fact that a reader </div>
                                </div>
                              </div>
                            </li>
                            <!--Block-->
                            <li class="accordion block">
                              <div class="acc-btn">What happens if my new home isn't ready on moving day?
                                <i class="icon fa-solid fa-plus"></i>
                              </div>
                              <div class="acc-content">
                                <div class="content">
                                  <div class="text">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a moreIt is a long established fact that a reader </div>
                                </div>
                              </div>
                            </li>
                            <!--Block-->
                            <li class="accordion block">
                              <div class="acc-btn">What should I do if my belongings are damaged or lost?
                                <i class="icon fa-solid fa-plus"></i>
                              </div>
                              <div class="acc-content">
                                <div class="content">
                                  <div class="text">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a moreIt is a long established fact that a reader </div>
                                </div>
                              </div>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Tab -->
            <div class="tab" id="prod-moving">
              <div class="tab-inner-content">
                <div class="row">
                  <div class="faq-column col-lg-12">
                    <div class="inner-column">
                      <div class="faq-box">
                        <div class="inner-box">
                          <ul class="accordion-box">
                            <!--Block-->
                            <li class="accordion block">
                              <div class="acc-btn">How far in advance should I schedule my move?
                                <i class="icon fa-solid fa-plus"></i>
                              </div>
                              <div class="acc-content">
                                <div class="content">
                                  <div class="text">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a moreIt is a long established fact that a reader </div>
                                </div>
                              </div>
                            </li>
                            <!--Block-->
                            <li class="accordion block active-block">
                              <div class="acc-btn active">What's the difference between a binding and non-binding estimate?
                                <i class="icon fa-solid fa-plus"></i>
                              </div>
                              <div class="acc-content current">
                                <div class="content">
                                  <div class="text">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a moreIt is a long established fact that a reader </div>
                                </div>
                              </div>
                            </li>
                            <!--Block-->
                            <li class="accordion block">
                              <div class="acc-btn">Do movers need to do an in-person survey to give an estimate?
                                <i class="icon fa-solid fa-plus"></i>
                              </div>
                              <div class="acc-content">
                                <div class="content">
                                  <div class="text">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a moreIt is a long established fact that a reader </div>
                                </div>
                              </div>
                            </li>
                            <!--Block-->
                            <li class="accordion block">
                              <div class="acc-btn">What happens if my new home isn't ready on moving day?
                                <i class="icon fa-solid fa-plus"></i>
                              </div>
                              <div class="acc-content">
                                <div class="content">
                                  <div class="text">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a moreIt is a long established fact that a reader </div>
                                </div>
                              </div>
                            </li>
                            <!--Block-->
                            <li class="accordion block">
                              <div class="acc-btn">What should I do if my belongings are damaged or lost?
                                <i class="icon fa-solid fa-plus"></i>
                              </div>
                              <div class="acc-content">
                                <div class="content">
                                  <div class="text">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a moreIt is a long established fact that a reader </div>
                                </div>
                              </div>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </section>
    <!-- end faq-section-three -->
<!-- start testimonial-section-three -->
    <section class="testimonial-section-three">
      <div class="outer-box">
        <div class="auto-container">
          <div class="row">
            <div class="content-column col-xl-6">
              <div class="inner-column">
                <div class="sec-title light">
                  <div class="h6 sub-title">Testimonial</div>
                  <div class="h2 title">The Best Customers <br>Says About <span>Our Action</span></div>
                </div>
                <div class="testimonial-block-three">
                  <div class="inner-block">
                    <div class="swiper-container testi-three-slider pb-0 overflow-hidden">
                      <div class="swiper-wrapper">
                        <div class="swiper-slide">
                          <div class="icon"><img src="images/icons/testi3-1.png" alt=""></div>
                          <div class="text">I'm an art collector and was terrified about moving several large, valuable pieces. Movingza sent a specialized crew who used the right material sand techniques. Not a single scratch! Their attention to detail .</div>
                          <div class="author-info">
                            <div class="image"><img src="images/resource/testi2-1.png" alt=""></div>
                            <div class="info">
                              <div class="h4 name">Jacob Jones</div>
                              <div class="designation">Business Owner</div>
                            </div>
                          </div>
                        </div>
                        <div class="swiper-slide">
                          <div class="icon"><img src="images/icons/testi3-1.png" alt=""></div>
                          <div class="text">I'm an art collector and was terrified about moving several large, valuable pieces. Movingza sent a specialized crew who used the right material sand techniques. Not a single scratch! Their attention to detail .</div>
                          <div class="author-info">
                            <div class="image"><img src="images/resource/testi2-1.png" alt=""></div>
                            <div class="info">
                              <div class="h4 name">Emily Carter</div>
                              <div class="designation">Business Owner</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="arrow-box">
                        <div class="testi-slider-prev"><i class="fa-solid fa-chevron-left"></i></div>
                        <div class="testi-slider-next"><i class="fa-solid fa-chevron-right"></i></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="image-column col-xl-6">
              <div class="inner-column">
                <div class="image"><img src="images/resource/testi3-1.jpg" alt=""></div>
                <div class="info-box">
                  <div class="counter-box">
                    <div class="h2 count-box"><span class="count-text" data-speed="3000" data-stop="4.8">0</span></div>
                    <div class="rating">
                      <i class="fa-solid fa-star"></i>
                      <i class="fa-solid fa-star"></i>
                      <i class="fa-solid fa-star"></i>
                      <i class="fa-solid fa-star"></i>
                      <i class="fa-solid fa-star"></i>
                    </div>
                  </div>
                  <div class="text">From 3k Members, <br>Reviewed by Google</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- end testimonial-section-three -->
<!-- start blog-section -->
    <section class="blog-section-two">
      <div class="auto-container">
        <div class="sec-title text-center">
          <div class="h6 sub-title">Our Blog</div>
          <div class="h2 title">Check out latest news <br><span>update & articles</span></div>
        </div>
        <div class="row gx-4">
          <div class="blog-block col-xl-4 col-md-6">
            <div class="inner-block">
              <div class="image-box">
                <div class="image">
                  <a href="news-details.php">
                    <img src="images/resource/blog1-1.jpg" alt="blog">
                    <img src="images/resource/blog1-1.jpg" alt="blog">
                  </a>
                </div>
              </div>
              <div class="content-box">
                <div class="post-meta">
                  <div class="category">Moving</div>
                  <div class="date">20 Dec, 2025</div>
                </div>
                <div class="h3 title"><a href="news-details.php">How to Pack Fragile Items the Right Way</a></div>
                <a class="btn-read-more" href="news-details.php"><i class="fa-regular fa-arrow-right"></i> Read More </a>
              </div>
            </div>
          </div>
          <div class="blog-block col-xl-4 col-md-6">
            <div class="inner-block">
              <div class="image-box">
                <div class="image">
                  <a href="news-details.php">
                    <img src="images/resource/blog1-2.jpg" alt="blog">
                    <img src="images/resource/blog1-2.jpg" alt="blog">
                  </a>
                </div>
              </div>
              <div class="content-box">
                <div class="post-meta">
                  <div class="category">Moving</div>
                  <div class="date">20 Dec, 2025</div>
                </div>
                <div class="h3 title"><a href="news-details.php">The Ultimate Checklist Before You Move</a></div>
                <a class="btn-read-more" href="news-details.php"><i class="fa-regular fa-arrow-right"></i> Read More </a>
              </div>
            </div>
          </div>
          <div class="blog-block col-xl-4 col-md-6">
            <div class="inner-block">
              <div class="image-box">
                <div class="image">
                  <a href="news-details.php">
                    <img src="images/resource/blog1-3.jpg" alt="blog">
                    <img src="images/resource/blog1-3.jpg" alt="blog">
                  </a>
                </div>
              </div>
              <div class="content-box">
                <div class="post-meta">
                  <div class="category">Moving</div>
                  <div class="date">20 Dec, 2025</div>
                </div>
                <div class="h3 title"><a href="news-details.php">The Best Packing Materials for Safe Moving</a></div>
                <a class="btn-read-more" href="news-details.php"><i class="fa-regular fa-arrow-right"></i> Read More </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- end blog-section -->
<!-- start cta-section -->
    <section class="cta-section">
      <div class="outer-box">
        <div class="bg-shape"><img src="images/icons/shape-13.png" alt=""></div>
        <div class="shape-1"><img src="images/icons/shape-11.png" alt=""></div>
        <div class="shape-2"><img src="images/icons/shape-12.png" alt=""></div>
        <div class="content">
          <div class="h2 title">Long-distance busy professionals whole-house moves</div>
          <a href="page-contact.php" class="theme-btn btn-style-one">Contact Us<i class="fa-light fa-arrow-up-right"></i></a>
        </div>
      </div>
    </section>
    <!-- end cta-section -->
<!-- Main Footer -->
    <footer class="main-footer footer-style-two">
      <div class="outer-box">
        <div class="shape-1"><img src="images/icons/shape-6.png" alt=""></div>
        <div class="shape-2"><img src="images/icons/footer2-1.png" alt=""></div>
        <div class="shape-3"><img src="images/icons/footer2-2.png" alt=""></div>
        <div class="auto-container">
          <!-- Widgets Section -->
          <div class="widgets-section">
            <div class="row gx-4">
              <!-- Footer Column -->
              <div class="footer-column col-xl-4 col-md-6">
                <div class="footer-widget about-widget">
                  <div class="logo"><img src="images/logo2.png" alt=""></div>
                  <div class="content">
                    <div class="text">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas</div>
                  </div>
                  <div class="info-box">
                    <div class="info">
                      <span><i class="fa-solid fa-phone-flip"></i>Any Help?</span>
                      <div class="h5">+1 (234) 568 000</div>
                    </div>
                    <div class="info">
                      <span><i class="fa-regular fa-envelope"></i>Email Us</span>
                      <div class="h5">support@gmail.com</div>
                    </div>
                  </div>
                </div>
              </div>
              <!-- Footer Column -->
              <div class="footer-column col-xl-2 col-md-6">
                <div class="footer-widget links-widget">
                  <div class="h5 widget-title">Company</div>
                  <div class="widget-content">
                    <ul class="user-links">
                      <li><a href="#/">About</a></li>
                      <li><a href="#/">Our Mission</a></li>
                      <li><a href="#/">Our Blogs</a></li>
                      <li><a href="#/">Help Center</a></li>
                      <li><a href="#/">Contact Us</a></li>
                    </ul>
                  </div>
                </div>
              </div>
              <!-- Footer Column -->
              <div class="footer-column col-xl-2 col-md-6">
                <div class="footer-widget links-widget style-two">
                  <div class="h5 widget-title">Service</div>
                  <div class="widget-content">
                    <ul class="user-links">
                      <li><a href="#/">Long-Distance Moving</a></li>
                      <li><a href="#/">Packing & Unpacking</a></li>
                      <li><a href="#/">Furniture Assembly</a></li>
                      <li><a href="#/">Residential Moving</a></li>
                      <li><a href="#/">Local Moving</a></li>
                    </ul>
                  </div>
                </div>
              </div>
              <!-- Footer Column -->
              <div class="footer-column col-xl-4 col-md-6">
                <div class="footer-widget subscribe-widget">
                  <div class="h5 widget-title">Newsletter</div>
                  <div class="text">Signup for our latest news & articles</div>
                  <div class="form-clt">
                    <input type="email" placeholder="Enter your email" required="" >
                    <button class="theme-btn btn-style-five" type="submit">Subscribe</button>
                  </div>
                  <form class="check-box">
                    <input type="checkbox" id="agree" name="agree" value="agree">
                    <label for="agree"> Agree to the <a href="index.php">Privacy Policy.</a></label>
                  </form>
                </div>
              </div>
            </div>
          </div>
          <div class="footer-bottom">
            <div class="inner-container">
              <p class="copyright-text">Copyright © 2026 Movingza . All Rights Reserved.</p>
            </div>
          </div>
          <div class="style-text-box"><div class="h1 style-text">Movingza</div></div>
        </div>
      </div>
    </footer>
    <!--End Main Footer -->

  </div>
<!-- End Page Wrapper -->

<script src="js/jquery.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/wow.js"></script>
<script src="js/select2.min.js"></script>
<script src="js/appear.js"></script>
<script src="js/bxslider.js"></script>
<script src="js/mixitup.js"></script>
<script src="js/knob.js"></script>
<script src="js/swiper.min.js"></script>
<script src="js/aos.js"></script>
<script src="js/gsap.min.js"></script>
<script src="js/ScrollTrigger.min.js"></script>
<script src="js/splitType.js"></script>
<script src="js/gsap-scroll-smoother.js"></script>
<script src="js/gsap-scroll-to-plugin.js"></script>
<script src="js/SplitText.min.js"></script>
<script src="js/custom-gsap.js"></script>
<script src="js/script.js"></script>
<!-- form submit -->
<script src="js/jquery.validate.min.js"></script>
<script src="js/jquery.form.min.js"></script>
<script src="js/contact-form-script.js"></script>
</body>
</html>
