<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Movingza - Movers & Packers PHP Template | Home Page 01</title>
  <link href="css/bootstrap.min.css" rel="stylesheet" />
  <link href="css/style.css" rel="stylesheet" />
  <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon" />
  <link rel="icon" href="images/favicon.png" type="image/x-icon" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>
<body>
<div class="page-wrapper">

    <div class="preloader"></div>

    <!-- Back-to-top start -->
    <div class="back-to-top-wrapper">
      <button id="back_to_top" type="button" class="back-to-top-btn">
        <svg width="12" height="7" viewBox="0 0 12 7" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M11 6L6 1L1 6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
        </svg>
      </button>
    </div>
    <!-- Back-to-top start -->

    <!-- Main Header-->
    <header class="main-header header-style-one">
      <div class="outer-box">
        <div class="header-lower anim-fade-move" data-delay="0.25">
          <div class="inner-container">
            <!-- Main box -->
            <div class="main-box">
              <div class="logo-box">
                <div class="logo">
                  <a href="index.php"><img src="images/logo.png" alt="Logo" /></a>
                </div>
              </div>

            </div>
            <!--Nav Box-->
            <div class="nav-outer">
              <nav class="nav main-menu">
                <ul class="navigation">
  <li class="current dropdown">
    <a href="index.php">Home</a>
    <ul>
      <li><a href="index.php">Home 01</a></li>
      <li><a href="index-2.php">Home 02</a></li>
      <li><a href="index-3.php">Home 03</a></li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">Pages</a>
    <ul>
      <li><a href="page-about.php">About Us</a></li>
      <li class="dropdown"><a href="#">Team</a>
        <ul>
          <li><a href="page-team.php">Team Grid</a></li>
          <li><a href="page-team-details.php">Team Details</a></li>
        </ul>
      </li>
      <li><a href="page-pricing.php">Pricing Plan</a></li>
      <li><a href="page-testimonial.php">Testimonials</a></li>
      <li><a href="page-faq.php">Faq</a></li>
      <li class="dropdown"><a href="#">Shop</a>
        <ul>
          <li><a href="shop-products.php">Products</a></li>
          <li><a href="shop-products-sidebar.php">Products with Sidebar</a></li>
          <li><a href="shop-product-details.php">Product Details</a></li>
          <li><a href="shop-cart.php">Cart</a></li>
          <li><a href="shop-checkout.php">Checkout</a></li>
        </ul>
      </li>
      <li><a href="page-404.php">404</a></li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">Services</a>
    <ul>
      <li><a href="page-services.php">Services Grid</a></li>
      <li><a href="page-service-details.php">Services Details</a></li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">Projects</a>
    <ul>
      <li><a href="page-projects.php">Project Grid</a></li>
      <li><a href="page-project-details.php">Project Details</a></li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">Blog</a>
    <ul>
      <li><a href="news-grid.php">Blog Grid</a></li>
      <li><a href="news-details.php">Blog Details</a></li>
    </ul>
  </li>
  <li class=""><a href="page-contact.php">Contact</a></li>
</ul>
              </nav>
            </div>
            <div class="right-box">
              <button class="ui-btn search-btn">
                <i class="fa-solid fa-magnifying-glass"></i>
              </button>
              <a class="theme-btn btn-style-five" href="page-contact.php">
                <span class="btn-title">Get Appointment </span>
              </a>
              <!--Mobile Navigation Toggler-->
              <div class="mobile-nav-toggler">
                <span></span>
                <span></span>
                <span></span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Mobile Menu  -->
      <div class="mobile-menu">
        <div class="menu-backdrop"></div>
        <!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
        <nav class="menu-box">
          <div class="upper-box">
            <div class="nav-logo">
              <a href="index.php"><img src="images/logo2.png" alt="" /></a>
            </div>
            <div class="close-btn"><i class="icon fa fa-times"></i></div>
          </div>
          <ul class="navigation clearfix">
            <!--Keep This Empty / Menu will come through Javascript-->
          </ul>
          <ul class="contact-list-one">
            <li>
              <i class="icon fa-regular fa-envelope"></i>
              <span class="title">Send Email</span>
              <div class="text"><a href="mailto:needhelp@company.com">needhelp@company.com</a></div>
            </li>
          </ul>
          <ul class="social-links">
            <li>
              <a href="#"><i class="icon fab fa-twitter"></i></a>
            </li>
            <li>
              <a href="#"><i class="icon fab fa-facebook-f"></i></a>
            </li>
            <li>
              <a href="#"><i class="icon fab fa-pinterest-p"></i></a>
            </li>
            <li>
              <a href="#"><i class="icon fab fa-vimeo-v"></i></a>
            </li>
          </ul>
        </nav>
      </div>
      <!-- End Mobile Menu -->

      <!-- Header Search -->
      <div class="search-popup">
        <span class="search-back-drop"></span>
        <button class="close-search"><span class="fa fa-times"></span></button>

        <div class="search-inner">
          <form method="post" action="index.php">
            <div class="form-group">
              <input type="search" name="search-field" value="" placeholder="Search..." required="" />
              <button type="submit"><i class="fa fa-search"></i></button>
            </div>
          </form>
        </div>
      </div>
      <!-- End Header Search -->

      <!-- Sticky Header  -->
      <div class="sticky-header">
        <div class="auto-container">
          <div class="inner-container">
            <!--Logo-->
            <div class="logo">
              <a href="index.php"><img src="images/logo.png" alt=""></a>
            </div>

            <!--Right Col-->
            <div class="nav-outer">
              <!-- Main Menu -->
              <nav class="main-menu">
                <div class="navbar-collapse show collapse clearfix">
                  <ul class="navigation clearfix">
                    <!--Keep This Empty / Menu will come through Javascript-->
                  </ul>
                </div>
              </nav>
              <!-- Main Menu End-->

              <!--Mobile Navigation Toggler-->
              <div class="mobile-nav-toggler">
                <span></span>
                <span></span>
                <span></span>
              </div>
            </div>
            
            <a href="tel:+8801750050088" class="header-phone_box">
              <span class="icon"><i aria-hidden="true" class="fas fa-phone-alt"></i></span>
              <span class="info">
                Call Anytime
                <strong>+8801750050088</strong>
              </span>
            </a>
          </div>
        </div>
      </div>
      <!-- End Sticky Menu -->
    </header>
    <!--End Main Header -->
<!-- start banner-section -->
    <section class="banner-section">
      <div class="outer-box">
        <div class="auto-container">
          <div class="banner-content">
            <div class="shape-1"><img src="images/icons/shape-1.png" alt=""></div>
            <div class="h1 banner-title">Professional Moving Services <img class="image-1" src="images/resource/banner1-1.png" alt="">Designed <span>for Peace of Mind</span><img class="image-2" src="images/resource/banner1-2.png" alt=""></div>
          </div>
        </div>
        <div class="form-container">
          <div class="bg bg-image"><img src="images/banner/banner1-1.jpg" alt=""></div>
          <div class="inner-container">
            <div class="auto-container">
              <div class="form-title text-center">
                <div class="h6 sub-title">Get your free moving estimate</div>
                <div class="h2 title">Request a Quote</div>
              </div>
              <div class="form-box">
                <div class="inner-box">
                  <form action="#">
                    <div class="row gx-4">
                      <div class="col-xl-4 col-md-6 wow fadeInUp animated" data-wow-delay=".2s">
                        <div class="form-clt">
                          <input type="text" name="name" id="name" placeholder="Your Name" required="">
                        </div>
                      </div>
                      <div class="col-xl-4 col-md-6 wow fadeInUp animated" data-wow-delay=".4s">
                        <div class="form-clt">
                          <input type="email" name="email" id="email" placeholder="Your Email">
                        </div>
                      </div>
                      <div class="col-xl-4 col-md-6 wow fadeInUp animated" data-wow-delay=".2s">
                        <div class="form-clt select">
                          <select class="move-select">
                            <option selected="" data-value="Move Type">Move Type</option>
                            <option data-value="optin 1">optin 1</option>
                            <option data-value="optin 2">optin 2</option>
                            <option data-value="optin 3">optin 3</option>
                          </select>
                        </div>
                      </div>
                      <div class="col-xl-3 col-md-6 wow fadeInUp animated" data-wow-delay=".2s">
                        <div class="form-clt">
                          <input type="text" name="name" id="From" placeholder="From">
                        </div>
                      </div>
                      <div class="col-xl-3 col-md-6 wow fadeInUp animated" data-wow-delay=".2s">
                        <div class="form-clt">
                          <input type="text" name="name" id="To" placeholder="To">
                        </div>
                      </div>
                      <div class="col-xl-3 col-md-6 wow fadeInUp animated" data-wow-delay=".2s">
                        <div class="form-clt">
                          <input type="date" id="day" name="day">
                        </div>
                      </div>
                      <div class="col-xl-3 col-md-6 wow fadeInUp animated" data-wow-delay=".2s">
                        <div class="form-clt">
                          <input type="text" name="name" id="To2" placeholder="Home Size">
                        </div>
                      </div>
                      <div class="col-md-12 wow fadeInUp animated text-center" data-wow-delay=".2s">
                        <button class="theme-btn btn-style-one" type="submit">Submit Request<i class="fa-light fa-arrow-up-right"></i></button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- end banner-section -->
<!-- start about-section -->
    <section class="about-section">
      <div class="auto-container">
        <div class="sec-title">
          <div class="h6 sub-title wow fadeInUp" data-wow-delay="200ms">About Us</div>
          <div class="h2 title wow fadeInUp" data-wow-delay="400ms">Experience a Better Way to Move With a Team <span>That Truly Cares</span></div>
        </div>
        <div class="upper-box wow fadeInUp" data-wow-delay="400ms">
          <div class="text">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. </div>
          <div class="author-info">
            <div class="image"><img src="images/resource/about1-1.png" alt=""></div>
            <div class="text">Based on 204 Reviews</div>
          </div>
        </div>
        <div class="row align-items-end">
          <div class="image-column col-lg-8 col-md-6 wow fadeInUp" data-wow-delay="600ms">
            <div class="row">
              <div class="col-lg-6">
                <div class="image">
                  <div class="img"><img src="images/resource/about1-1.jpg" alt=""></div>
                </div>
              </div>
              <div class="col-lg-6">
                <div class="image two">
                  <div class="img"><img src="images/resource/about1-2.jpg" alt=""></div>
                </div>
              </div>
            </div>
          </div>
          <div class="content-column col-lg-3 col-md-6 offset-xl-1">
            <div class="inner-column wow fadeInUp" data-wow-delay="700ms">
              <div class="funfact-box">
                <div class="inner-box">
                  <div class="h6 title">Satisfaction</div>
                  <div class="count-info">
                    <div class="count-box"><span class="count-text" data-speed="3000" data-stop="98">0</span>%</div>
                    <div class="text">Satisfaction <br>Guaranteed</div>
                  </div>
                </div>
              </div>
              <div class="funfact-box">
                <div class="inner-box">
                  <div class="h6 title">Countries</div>
                  <div class="count-info">
                    <div class="count-box"><span class="count-text" data-speed="3000" data-stop="150">0</span>+</div>
                    <div class="text">Expanding <br>in 25 Countries</div>
                  </div>
                </div>
              </div>
              <a href="page-about.php" class="theme-btn btn-style-one">More About Us<i class="fa-light fa-arrow-up-right"></i></a>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- end about-section -->
<!-- start services-section-two -->
    <section class="services-section-two">
      <div class="outer-box">
        <div class="outer-container">
          <div class="sec-title text-center light wow fadeInUp" data-wow-delay="200ms">
            <div class="h6 sub-title">Our Service</div>
            <div class="h2 title">Reliable Moving Services for Homes <span>& Businesses</span></div>
          </div>
          <div class="service-two-slider swiper-container pb-0">
            <div class="swiper-wrapper wow fadeInUp" data-wow-delay="400ms">
              <div class="service-block-three swiper-slide">
                <div class="inner-block">
                  <div class="image">
                    <a href="page-service-details.php">
                      <img src="images/resource/service3-1.jpg" alt="blog">
                      <img src="images/resource/service3-1.jpg" alt="blog">
                    </a>
                  </div>
                  <div class="content-box">
                    <div class="inner-box">
                      <div class="icon"><i class="flaticon-home-delivery"></i></div>
                      <div class="content">
                        <div class="h4 title"><a href="page-service-details.php">Residential Moving</a></div>
                        <div class="text">On the other hand, we denounce with righteous indignation </div>
                      </div>
                      <div class="counte">01</div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="service-block-three swiper-slide">
                <div class="inner-block">
                  <div class="image">
                    <a href="page-service-details.php">
                      <img src="images/resource/service3-2.jpg" alt="blog">
                      <img src="images/resource/service3-2.jpg" alt="blog">
                    </a>
                  </div>
                  <div class="content-box">
                    <div class="inner-box">
                      <div class="icon"><i class="flaticon-delivery-man-2"></i></div>
                      <div class="content">
                        <div class="h4 title"><a href="page-service-details.php">Commercial Moving</a></div>
                        <div class="text">On the other hand, we denounce with righteous indignation </div>
                      </div>
                      <div class="counte">02</div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="service-block-three swiper-slide">
                <div class="inner-block">
                  <div class="image">
                    <a href="page-service-details.php">
                      <img src="images/resource/service3-3.jpg" alt="blog">
                      <img src="images/resource/service3-3.jpg" alt="blog">
                    </a>
                  </div>
                  <div class="content-box">
                    <div class="inner-box">
                      <div class="icon"><i class="flaticon-delivery"></i></div>
                      <div class="content">
                        <div class="h4 title"><a href="page-service-details.php">Furniture Disassembly</a></div>
                        <div class="text">On the other hand, we denounce with righteous indignation </div>
                      </div>
                      <div class="counte">03</div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="service-block-three swiper-slide">
                <div class="inner-block">
                  <div class="image">
                    <a href="page-service-details.php">
                      <img src="images/resource/service3-3.jpg" alt="blog">
                      <img src="images/resource/service3-3.jpg" alt="blog">
                    </a>
                  </div>
                  <div class="content-box">
                    <div class="inner-box">
                      <div class="icon"><i class="flaticon-cargo"></i></div>
                      <div class="content">
                        <div class="h4 title"><a href="page-service-details.php">Local Moving</a></div>
                        <div class="text">On the other hand, we denounce with righteous indignation </div>
                      </div>
                      <div class="counte">04</div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="service-block-three swiper-slide">
                <div class="inner-block">
                  <div class="image">
                    <a href="page-service-details.php">
                      <img src="images/resource/service3-2.jpg" alt="blog">
                      <img src="images/resource/service3-2.jpg" alt="blog">
                    </a>
                  </div>
                  <div class="content-box">
                    <div class="inner-box">
                      <div class="icon"><i class="flaticon-logistic"></i></div>
                      <div class="content">
                        <div class="h4 title"><a href="page-service-details.php">Commercial Moving</a></div>
                        <div class="text">On the other hand, we denounce with righteous indignation </div>
                      </div>
                      <div class="counte">05</div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="service-block-three swiper-slide">
                <div class="inner-block">
                  <div class="image">
                    <a href="page-service-details.php">
                      <img src="images/resource/service3-3.jpg" alt="blog">
                      <img src="images/resource/service3-3.jpg" alt="blog">
                    </a>
                  </div>
                  <div class="content-box">
                    <div class="inner-box">
                      <div class="icon"><i class="flaticon-team"></i></div>
                      <div class="content">
                        <div class="h4 title"><a href="page-service-details.php">Furniture Disassembly</a></div>
                        <div class="text">On the other hand, we denounce with righteous indignation </div>
                      </div>
                      <div class="counte">06</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="service-two-dots"></div>
          </div>
        </div>
      </div>
    </section>
    <!-- end services-section-two -->
<!-- start working-section-three  -->
    <section class="working-section">
      <div class="auto-container">
        <div class="row">
          <div class="col-lg-6">
            <div class="sec-title wow fadeInUp" data-wow-delay="200ms">
              <div class="h6 sub-title">How It Works</div>
              <div class="h2 title">Simple Process for <br>a <span>Smooth Move</span></div>
            </div>
            <div class="hiw-image-box wow fadeInUp" data-wow-delay="400ms">
              <div class="inner-box">
                <div class="image-box">
                  <img src="images/resource/how-it-work.jpg" alt="">
                  <img src="images/resource/how-it-work.jpg" alt="">
                </div>
                <div class="features">
                  <ul>
                    <li><i class="icon fas fa-check-circle"></i> <span>Safe lifting practices and modern tools</span></li>
                    <li><i class="icon fas fa-check-circle"></i> <span>Fragile, artwork, electronics, and heavy items</span></li>
                    <li><i class="icon fas fa-check-circle"></i> <span>High-quality packing materials for maximum protection</span></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-6 wow fadeInUp" data-wow-delay="600ms">
            <div class="working-block">
              <div class="inner-block active">
                <div class="counter one"><span>01</span></div>
                <div class="content-box">
                  <div class="step">Step</div>
                  <div class="h5 title">Request a Free Quote</div>
                  <div class="text">Tell us about your move and get a fast, accurate estimate.</div>
                </div>
              </div>
            </div>

            <div class="working-block">
              <div class="inner-block">
                <div class="counter two"><span>02</span></div>
                <div class="content-box">
                  <div class="step">Step</div>
                  <div class="h5 title">We Pack & Prepare</div>
                  <div class="text">Our team carefully packs your belongings and gets everything ready.</div>
                </div>
              </div>
            </div>

            <div class="working-block">
              <div class="inner-block">
                <div class="counter three"><span>03</span></div>
                <div class="content-box">
                  <div class="step">Step</div>
                  <div class="h5 title">We Move Your Items Safely</div>
                  <div class="text">We transport your items securely to your new destination.</div>
                </div>
              </div>
            </div>

            <div class="working-block">
              <div class="inner-block">
                <div class="counter four"><span>04</span></div>
                <div class="content-box">
                  <div class="step">Step</div>
                  <div class="h5 title">Unload & Set Up</div>
                  <div class="text">We help with unpacking and furniture placement as needed.</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- end working-section-three -->
<!-- Funfact Section -->
    <section class="funfact-section pt-0">
      <div class="h4 funfact-title">Our Experience Speaks for Itself</div>
      <div class="container">
        <div class="inner-row">
          <div class="funfact-block">
            <div class="inner-block">
              <div class="text">Successful Moves <br>Completed</div>
              <div class="h3 count-box"><span class="count-text" data-speed="3000" data-stop="1500">0</span>+</div>
            </div>
          </div>
          <div class="funfact-block">
            <div class="inner-block">
              <div class="text">Customer <br>Satisfaction Rate</div>
              <div class="h3 count-box"><span class="count-text" data-speed="3000" data-stop="98">0</span>%</div>
            </div>
          </div>
          <div class="funfact-block">
            <div class="inner-block">
              <div class="text">Local & Long-Distance <br>Routes Served</div>
              <div class="h3 count-box"><span class="count-text" data-speed="3000" data-stop="4.9">0</span>/5</div>
            </div>
          </div>
          <div class="funfact-block">
            <div class="inner-block">
              <div class="text">Trained & <br>Professional Movers</div>
              <div class="h3 count-box"><span class="count-text" data-speed="3000" data-stop="50">0</span>+</div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- End Funfact Section -->
<!-- Project Section -->
    <section class="services-section pt-0">
      <div class="outer-container">
        <div class="auto-container">
          <div class="sec-title">
            <div class="row align-items-end">
              <div class="col-xl-2">
                <div class="h6 sub-title">Project</div>
              </div>
              <div class="col-xl-7">
                <div class="h2 title">Our Most Recent <br>Moving <span>Projects Portfolio</span></div>
              </div>
              <div class="col-xl-3">
                <div class="text">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</div>
              </div>
            </div>
          </div>
        </div>
        <div class="outer-box" data-background="./images/resource/service1-bg1.jpg">
          <div class="service-one-slider swiper-container">
            <div class="swiper-wrapper">
              <div class="swiper-slide">
                <div class="service-block" data-bg="./images/resource/service1-bg1.jpg">
                  <div class="inner-box">
                    <div class="content">
                      <div class="h6 sub-title">
                        <span class="text">Moving</span>
                        <span class="text">Residential</span>
                      </div>
                      <div class="h3 title"><a href="page-projects.php">Complete Residential Home Move</a></div>
                      <div class="text">It is a long established fact that a reader will be distracted by the readable</div>
                      <div class="btn-box">
                        <a class="btn-arrow" href="page-project-details.php">View Project <i class="fa fa-arrow-right"></i></a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="swiper-slide">
                <div class="service-block" data-bg="./images/resource/service1-bg2.jpg">
                  <div class="inner-box">
                    <div class="content">
                      <div class="h6 sub-title">
                        <span class="text">Moving</span>
                        <span class="text">Residential</span>
                      </div>
                      <div class="h3 title"><a href="page-projects.php">Full Office Relocation Project</a></div>
                      <div class="text">It is a long established fact that a reader will be distracted by the readable</div>
                      <div class="btn-box">
                        <a class="btn-arrow" href="page-project-details.php">View Project <i class="fa fa-arrow-right"></i></a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="swiper-slide">
                <div class="service-block" data-bg="./images/resource/service1-bg3.jpg">
                  <div class="inner-box">
                    <div class="content">
                      <div class="h6 sub-title">
                        <span class="text">Moving</span>
                        <span class="text">Residential</span>
                      </div>
                      <div class="h3 title"><a href="page-projects.php">Long-Distance Household Move</a></div>
                      <div class="text">It is a long established fact that a reader will be distracted by the readable</div>
                      <div class="btn-box">
                        <a class="btn-arrow" href="page-project-details.php">View Project <i class="fa fa-arrow-right"></i></a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="swiper-slide">
                <div class="service-block" data-bg="./images/resource/service1-bg4.jpg">
                  <div class="inner-box">
                    <div class="content">
                      <div class="h6 sub-title">
                        <span class="text">Moving</span>
                        <span class="text">Residential</span>
                      </div>
                      <div class="h3 title"><a href="page-projects.php">Apartment-to-House Moving Service</a></div>
                      <div class="text">It is a long established fact that a reader will be distracted by the readable</div>
                      <div class="btn-box">
                        <a class="btn-arrow" href="page-project-details.php">View Project <i class="fa fa-arrow-right"></i></a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="swiper-slide">
                <div class="service-block" data-bg="./images/resource/service1-bg1.jpg">
                  <div class="inner-box">
                    <div class="content">
                      <div class="h6 sub-title">
                        <span class="text">Moving</span>
                        <span class="text">Residential</span>
                      </div>
                      <div class="h3 title"><a href="page-projects.php">Complete Residential Home Move</a></div>
                      <div class="text">It is a long established fact that a reader will be distracted by the readable</div>
                      <div class="btn-box">
                        <a class="btn-arrow" href="page-project-details.php">View Project <i class="fa fa-arrow-right"></i></a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="swiper-slide">
                <div class="service-block" data-bg="./images/resource/service1-bg2.jpg">
                  <div class="inner-box">
                    <div class="content">
                      <div class="h6 sub-title">
                        <span class="text">Moving</span>
                        <span class="text">Residential</span>
                      </div>
                      <div class="h3 title"><a href="page-projects.php">Full Office Relocation Project</a></div>
                      <div class="text">It is a long established fact that a reader will be distracted by the readable</div>
                      <div class="btn-box">
                        <a class="btn-arrow" href="page-project-details.php">View Project <i class="fa fa-arrow-right"></i></a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="swiper-slide">
                <div class="service-block" data-bg="./images/resource/service1-bg3.jpg">
                  <div class="inner-box">
                    <div class="content">
                      <div class="h6 sub-title">
                        <span class="text">Moving</span>
                        <span class="text">Residential</span>
                      </div>
                      <div class="h3 title"><a href="page-projects.php">Long-Distance Household Move</a></div>
                      <div class="text">It is a long established fact that a reader will be distracted by the readable</div>
                      <div class="btn-box">
                        <a class="btn-arrow" href="page-project-details.php">View Project <i class="fa fa-arrow-right"></i></a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="swiper-slide">
                <div class="service-block" data-bg="./images/resource/service1-bg4.jpg">
                  <div class="inner-box">
                    <div class="content">
                      <div class="h6 sub-title">
                        <span class="text">Moving</span>
                        <span class="text">Residential</span>
                      </div>
                      <div class="h3 title"><a href="page-projects.php">Apartment-to-House Moving Service</a></div>
                      <div class="text">It is a long established fact that a reader will be distracted by the readable</div>
                      <div class="btn-box">
                        <a class="btn-arrow" href="page-project-details.php">View Project <i class="fa fa-arrow-right"></i></a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="arrow-box">
              <button class="slider-prev">
                <i class="fa-regular fa-arrow-left"></i>
              </button>
              <button class="slider-next">
                <i class="fa-regular fa-arrow-right"></i>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- End Project Section -->
<!-- start why-choose-us-section -->
    <section class="why-choose-us-section pb-90 pt-0">
      <div class="auto-container">
        <div class="sec-title text-center">
          <div class="h6 sub-title">Why Choose Us</div>
          <div class="h2 title">Why Choose Our <span>Moving Experts?</span></div>
          <div class="text">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. </div>
        </div>
        <div class="row">
          <div class="image-column col-xl-4 col-lg-4">
            <div class="inner-column">
              <div class="image"><img src="images/resource/wcu1-1.jpg" alt=""></div>
            </div>
          </div>
          <div class="content-column col-xl-5 col-lg-8">
            <div class="inner-column">
              <div class="feature-item">
                <div class="inner-block">
                  <div class="icon"><i class="flaticon-shipment"></i></div>
                  <div class="content">
                    <div class="h4 title"><a href="page-service-details.php">Transparent & Fair Pricing</a></div>
                    <div class="text">Our experienced movers handle every item with care, ensuring a smooth</div>
                  </div>
                </div>
              </div>
              <div class="feature-item">
                <div class="inner-block active">
                  <div class="icon"><i class="flaticon-delivery-man-1"></i></div>
                  <div class="content">
                    <div class="h4 title"><a href="page-service-details.php">Professional & Experienced Team</a></div>
                    <div class="text">Our experienced movers handle every item with care, ensuring a smooth</div>
                  </div>
                </div>
              </div>
              <div class="feature-item">
                <div class="inner-block">
                  <div class="icon"><i class="flaticon-delivery-man"></i></div>
                  <div class="content">
                    <div class="h4 title"><a href="page-service-details.php">Fast & On-Time Service</a></div>
                    <div class="text">Our experienced movers handle every item with care, ensuring a smooth</div>
                  </div>
                </div>
              </div>
              <div class="feature-item">
                <div class="inner-block">
                  <div class="icon"><i class="flaticon-cash-on-delivery"></i></div>
                  <div class="content">
                    <div class="h4 title"><a href="page-service-details.php">Fully Insured & Secure</a></div>
                    <div class="text">Our experienced movers handle every item with care, ensuring a smooth</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-xl-3">
            <div class="anim-shape"><img src="images/icons/wcu1-1.png" alt=""></div>
          </div>
        </div>
      </div>
    </section>
    <!-- end why-choose-us-section -->
<!-- start faq-section -->
    <section class="faq-section pt-0">
      <div class="outer-box pb-100">
        <div class="auto-container">
          <div class="row">
            <div class="content-column col-lg-5">
              <div class="inner-column">
                <div class="sec-title light">
                  <div class="h6 sub-title">FAQS</div>
                  <div class="h2 title">Answers Most <br>Common <span>Queries!</span></div>
                </div>
                <div class="content-box">
                  <div class="inner-box">
                    <div class="h3 title">Have Any Question on Your Minds?</div>
                    <a href="page-contact.php" class="theme-btn btn-style-five">Get In Touch</a>
                  </div>
                </div>
              </div>
            </div>
            <div class="faq-column col-lg-7">
              <div class="inner-column wow fadeInUp" data-wow-delay="200ms">
                <div class="faq-box">
                  <div class="inner-box">
                    <ul class="accordion-box">
                      <!--Block-->
                      <li class="accordion block">
                        <div class="acc-btn">How early should I book my moving date?
                          <i class="fa-solid fa-plus"></i>
                        </div>
                        <div class="acc-content">
                          <div class="content">
                            <div class="text">The amount you can save with solar depends on several key factors, but many homeowners save anywhere from 40% to 100% on their electricity</div>
                          </div>
                        </div>
                      </li>
                      <!--Block-->
                      <li class="accordion block active-block">
                        <div class="acc-btn active">Do you provide free estimates for moving services?
                          <i class="fa-solid fa-plus"></i>
                        </div>
                        <div class="acc-content current">
                          <div class="content">
                            <div class="text">The amount you can save with solar depends on several key factors, but many homeowners save anywhere from 40% to 100% on their electricity</div>
                          </div>
                        </div>
                      </li>
                      <!--Block-->
                      <li class="accordion block">
                        <div class="acc-btn">Can you move large items like pianos or safes?
                          <i class="fa-solid fa-plus"></i>
                        </div>
                        <div class="acc-content">
                          <div class="content">
                            <div class="text">The amount you can save with solar depends on several key factors, but many homeowners save anywhere from 40% to 100% on their electricity</div>
                          </div>
                        </div>
                      </li>
                      <!--Block-->
                      <li class="accordion block">
                        <div class="acc-btn">Should I pack my belongings myself or let the movers do it?
                          <i class="fa-solid fa-plus"></i>
                        </div>
                        <div class="acc-content">
                          <div class="content">
                            <div class="text">The amount you can save with solar depends on several key factors, but many homeowners save anywhere from 40% to 100% on their electricity</div>
                          </div>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- end faq-section -->
<!-- Testimonial Section -->
    <section class="testimonial-section">
      <div class="outer-container">
        <div class="sec-title text-center">
          <div class="h6 sub-title">Testimonial</div>
          <div class="h2 title">The Best Customers Says <br>About <span>Our Action</span></div>
        </div>
        <div class="row gx-4">
          <div class="col-xl-6">
            <div class="testimonial-block">
              <div class="inner-box">
                <div class="content-box">
                  <div class="logo"><img src="images/icons/testi1-1.png" alt=""></div>
                  <div class="h4 focus-text">The team was incredibly professional</div>
                  <div class="h5 text">"The team handled every piece of furniture with care and attention. They were punctual, friendly, and made the whole move effortless"</div>
                  <div class="info-box">
                    <div class="user-info">
                      <div class="h5 name">Emily Carter</div>
                      <span class="designation">Senior Project Manager</span>
                    </div>
                    <div class="rating">
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                    </div>
                  </div>
                </div>
                <figure class="image-box">
                  <img src="images/resource/testimonial1-1.jpg" alt="">
                  <a href="https://www.youtube.com/watch?v=Lplq8RjQ0zU" data-fancybox="gallery" class="video-btn playbtnanim"><i class="fa-sharp fa-solid fa-play"></i></a>
                </figure>
              </div>
            </div>
          </div>
          <div class="col-xl-6">
            <div class="testimonial-block">
              <div class="inner-box">
                <div class="content-box">
                  <div class="logo"><img src="images/icons/testi1-1.png" alt=""></div>
                  <div class="h4 focus-text">The team was incredibly professional</div>
                  <div class="h5 text">"The team handled every piece of furniture with care and attention. They were punctual, friendly, and made the whole move effortless"</div>
                  <div class="info-box">
                    <div class="user-info">
                      <div class="h5 name">Emily Carter</div>
                      <span class="designation">Senior Project Manager</span>
                    </div>
                    <div class="rating">
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                    </div>
                  </div>
                </div>
                <figure class="image-box">
                  <img src="images/resource/testimonial1-2.jpg" alt="">
                  <a href="https://www.youtube.com/watch?v=Lplq8RjQ0zU" data-fancybox="gallery" class="video-btn playbtnanim"><i class="fa-sharp fa-solid fa-play"></i></a>
                </figure>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- End Testimonial Section -->
<!-- start video-section -->
    <section class="video-section">
      <div class="outer-box">
        <div class="bg-image wow reveal-top tm-gsap-img-parallax overflow-hidden"><img src="images/resource/video1-1.jpg" alt=""></div>
        <div class="video-box wow fadeInUp animated animated" data-wow-delay="200ms">
          <a class="play-now-one play-now" href="https://www.youtube.com/watch?v=hddwAIXbKZo" data-fancybox="gallery" data-caption="">
            <i class="fa-sharp fa-solid fa-play"></i>
          </a>
        </div>
        <div class="content">
          <div class="title">Experience the Quality Behind Our Service</div>
        </div>
      </div>
    </section>
    <!-- end video-section -->
<!-- start pricing-section -->
    <section class="pricing-section">
      <div class="auto-container">
        <div class="sec-title text-center">
          <div class="h6 sub-title">Pricing Plan</div>
          <div class="h2 title">Select a Plan According to <br>Your <span>Requirements</span></div>
        </div>
        <div class="row gx-4">
          <div class="col-lg-6">
            <div class="pricing-block">
              <div class="inner-block">
                <div class="popular-ribbon">Most Popular</div>
                <div class="shape-one"><img src="images/icons/shape1.png" alt=""></div>
                <div class="h4 price-title">Basic Move</div>
                <div class="text">Perfect for small apartments</div>
                <div class="price-area">
                  <div class="h2 price">$130 <span>/visit</span></div>
                </div>
                <div class="feature-lists">
                  <div class="row">
                    <div class="col-sm-6">
                      <ul class="features-list">
                        <li><i class="icon fa-classic far fa-check"></i>1 Moving Truck (Up to 14 ft)</li>
                        <li><i class="icon fa-classic far fa-check"></i>Professional Movers</li>
                        <li class="light"><i class="icon fa-classic far fa-check"></i>Basic Loading & Unloading</li>
                        <li class="light"><i class="icon fa-classic far fa-check"></i>Up to 2 Hours of Service</li>
                      </ul>
                    </div>
                    <div class="col-sm-6">
                      <ul class="features-list">
                        <li><i class="icon fa-classic far fa-check"></i>Basic Insurance Coverage</li>
                        <li><i class="icon fa-classic far fa-check"></i>Professional Movers</li>
                        <li class="light"><i class="icon fa-classic far fa-check"></i>Basic Loading & Unloading</li>
                        <li class="light"><i class="icon fa-classic far fa-check"></i>Up to 2 Hours of Service</li>
                      </ul>
                    </div>
                  </div>
                </div>
                <a href="page-pricing.php" class="theme-btn btn-style-two w-100">Select Plan<i class="fa-light fa-arrow-up-right"></i></a>
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="pricing-block">
              <div class="inner-block active">
                <div class="popular-ribbon">Most Popular</div>
                <div class="shape-one"><img src="images/icons/shape1.png" alt=""></div>
                <div class="h4 price-title">Premium Move</div>
                <div class="text">Large homes & long-distance</div>
                <div class="price-area">
                  <div class="h2 price">$699 <span>/visit</span></div>
                </div>
                <div class="feature-lists">
                  <div class="row">
                    <div class="col-sm-6">
                      <ul class="features-list">
                        <li><i class="icon fa-classic far fa-check"></i>1 Moving Truck (Up to 14 ft)</li>
                        <li><i class="icon fa-classic far fa-check"></i>Professional Movers</li>
                        <li><i class="icon fa-classic far fa-check"></i>Basic Loading & Unloading</li>
                        <li class="light"><i class="icon fa-classic far fa-check"></i>Up to 2 Hours of Service</li>
                      </ul>
                    </div>
                    <div class="col-sm-6">
                      <ul class="features-list">
                        <li><i class="icon fa-classic far fa-check"></i>Basic Insurance Coverage</li>
                        <li><i class="icon fa-classic far fa-check"></i>Professional Movers</li>
                        <li><i class="icon fa-classic far fa-check"></i>Basic Loading & Unloading</li>
                        <li class="light"><i class="icon fa-classic far fa-check"></i>Up to 2 Hours of Service</li>
                      </ul>
                    </div>
                  </div>
                </div>
                <a href="page-pricing.php" class="theme-btn btn-style-two w-100">Select Plan<i class="fa-light fa-arrow-up-right"></i></a>
              </div>
            </div>
          </div>
        </div>
        <div class="content-box">
          <div class="inner-box">
            <div class="content">
              <div class="h3 title">Need a Custom Plan</div>
              <div class="text">It is a long established fact that a reader will be distracted by the readable content of a page looking. </div>
            </div>
            <ul class="price-range">
              <li>
                <span><i class="fa-regular fa-circle-check"></i> Unlimited Pages</span>
                <span><i class="fa-regular fa-circle-check"></i> Advanced analytics</span>
              </li>
              <li>
                <span><i class="fa-regular fa-circle-check"></i> Unlimited Pages</span>
                <span><i class="fa-regular fa-circle-check"></i> Advanced analytics</span>
              </li>
            </ul>
            <a href="page-contact.php" class="theme-btn btn-style-three">Contact Us<i class="fa-light fa-arrow-up-right"></i></a>
          </div>
        </div>
      </div>
    </section>
    <!-- end pricing-section -->
<!-- start Team section-->
    <section class="team-section pt-0">
      <div class="outer-box pb-100">
        <div class="auto-container">
          <div class="sec-title text-center light">
            <div class="h6 sub-title">Our Team</div>
            <div class="h2 title">Dedicated Professionals <br>Behind <span>Your Move</span></div>
          </div>
          <div class="team-block">
            <div class="inner-block">
              <div class="content">
                <div class="h3 title"><a href="page-team-details.php">Ethan Walker</a></div>
                <div class="text">Customer Support Manager, <span>Ensures smooth, organized, on-time moves.</span></div>
              </div>
              <div class="hover-image" style="background-image: url(images/resource/team-bg1.jpg);"></div>
              <div class="social-icon">
                <a href="#"><i class="fa-brands fa-facebook-f"></i></a>
                <a href="#"><i class="fa-brands fa-twitter"></i></a>
                <a href="#"><i class="fa-brands fa-pinterest-p"></i></a>
                <a href="#"><i class="fa-brands fa-youtube"></i></a>
              </div>
            </div>
          </div>
          <div class="team-block">
            <div class="inner-block">
              <div class="content">
                <div class="h3 title"><a href="page-team-details.php">Olivia Brooks</a></div>
                <div class="text">Customer Support <span>Helps customers with booking and preparation.</span></div>
              </div>
              <div class="hover-image" style="background-image: url(images/resource/team-bg1.jpg);"></div>
              <div class="social-icon">
                <a href="#"><i class="fa-brands fa-facebook-f"></i></a>
                <a href="#"><i class="fa-brands fa-twitter"></i></a>
                <a href="#"><i class="fa-brands fa-pinterest-p"></i></a>
                <a href="#"><i class="fa-brands fa-youtube"></i></a>
              </div>
            </div>
          </div>
          <div class="team-block">
            <div class="inner-block">
              <div class="content">
                <div class="h3 title"><a href="page-team-details.php">Daniel Carter</a></div>
                <div class="text">Moving Specialist, <span>Expert in handling heavy and fragile items.</span></div>
              </div>
              <div class="hover-image" style="background-image: url(images/resource/team-bg1.jpg);"></div>
              <div class="social-icon">
                <a href="#"><i class="fa-brands fa-facebook-f"></i></a>
                <a href="#"><i class="fa-brands fa-twitter"></i></a>
                <a href="#"><i class="fa-brands fa-pinterest-p"></i></a>
                <a href="#"><i class="fa-brands fa-youtube"></i></a>
              </div>
            </div>
          </div>
          <div class="team-block">
            <div class="inner-block">
              <div class="content">
                <div class="h3 title"><a href="page-team-details.php">Sophia Martinez</a></div>
                <div class="text">Packing Expert, <span>Skilled in delicate, safe, organized packing.</span></div>
              </div>
              <div class="hover-image" style="background-image: url(images/resource/team-bg1.jpg);"></div>
              <div class="social-icon">
                <a href="#"><i class="fa-brands fa-facebook-f"></i></a>
                <a href="#"><i class="fa-brands fa-twitter"></i></a>
                <a href="#"><i class="fa-brands fa-pinterest-p"></i></a>
                <a href="#"><i class="fa-brands fa-youtube"></i></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- End Team section -->
<!-- start blog-section -->
    <section class="blog-section">
      <div class="auto-container">
        <div class="sec-title-box">
          <div class="sec-title">
            <div class="h6 sub-title">Our Blog</div>
            <div class="h2 title">Check out latest <br>news <span>update & articles</span></div>
          </div>
          <a href="news-grid.php" class="theme-btn btn-style-three">See All Article<i class="fa-light fa-arrow-up-right"></i></a>
        </div>
        <div class="row gx-4">
          <div class="blog-block col-xl-4 col-md-6">
            <div class="inner-block">
              <div class="image-box">
                <div class="image">
                  <a href="news-details.php">
                    <img src="images/resource/blog1-1.jpg" alt="blog">
                    <img src="images/resource/blog1-1.jpg" alt="blog">
                  </a>
                </div>
              </div>
              <div class="content-box">
                <div class="post-meta">
                  <div class="category">Moving</div>
                  <div class="date">20 Dec, 2025</div>
                </div>
                <div class="h3 title"><a href="news-details.php">How to Pack Fragile Items the Right Way</a></div>
                <a class="btn-read-more" href="news-details.php"><i class="fa-regular fa-arrow-right"></i> Read More </a>
              </div>
            </div>
          </div>
          <div class="blog-block col-xl-4 col-md-6">
            <div class="inner-block">
              <div class="image-box">
                <div class="image">
                  <a href="news-details.php">
                    <img src="images/resource/blog1-2.jpg" alt="blog">
                    <img src="images/resource/blog1-2.jpg" alt="blog">
                  </a>
                </div>
              </div>
              <div class="content-box">
                <div class="post-meta">
                  <div class="category">Moving</div>
                  <div class="date">20 Dec, 2025</div>
                </div>
                <div class="h3 title"><a href="news-details.php">The Ultimate Checklist Before You Move</a></div>
                <a class="btn-read-more" href="news-details.php"><i class="fa-regular fa-arrow-right"></i> Read More </a>
              </div>
            </div>
          </div>
          <div class="blog-block col-xl-4 col-md-6">
            <div class="inner-block">
              <div class="image-box">
                <div class="image">
                  <a href="news-details.php">
                    <img src="images/resource/blog1-3.jpg" alt="blog">
                    <img src="images/resource/blog1-3.jpg" alt="blog">
                  </a>
                </div>
              </div>
              <div class="content-box">
                <div class="post-meta">
                  <div class="category">Moving</div>
                  <div class="date">20 Dec, 2025</div>
                </div>
                <div class="h3 title"><a href="news-details.php">The Best Packing Materials for Safe Moving</a></div>
                <a class="btn-read-more" href="news-details.php"><i class="fa-regular fa-arrow-right"></i> Read More </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- end blog-section -->
<!-- Main Footer -->
    <footer class="main-footer footer-style-one">
      <div class="auto-container">
        <div class="style-text-box"><div class="h1 style-text">Movingza</div></div>
        <!-- Widgets Section -->
        <div class="widgets-section">
          <div class="row gx-4">
            <!-- Footer Column -->
            <div class="footer-column col-lg-4 col-md-6">
              <div class="footer-widget subscribe-widget">
                <div class="h3 widget-title">Subscribe to Our Newsletter</div>
                <div class="form-clt">
                  <input type="email" placeholder="Enter email" required="" >
                  <button class="theme-btn btn-style-five" type="submit">Subscribe</button>
                </div>
                <form class="check-box">
                  <input type="checkbox" id="agree" name="agree" value="agree">
                  <label for="agree"> I agree to the <a href="index.php">privacy policy.</a></label>
                </form>
              </div>
            </div>
            <!-- Footer Column -->
            <div class="footer-column col-lg-2 col-md-6">
              <div class="footer-widget links-widget">
                <div class="h5 widget-title">Company</div>
                <div class="widget-content">
                  <ul class="user-links">
                    <li><a href="#/">About</a></li>
                    <li><a href="#/">Our Mission</a></li>
                    <li><a href="#/">Our Blogs</a></li>
                    <li><a href="#/">Help Center</a></li>
                    <li><a href="#/">Contact Us</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <!-- Footer Column -->
            <div class="footer-column col-lg-3 col-md-6">
              <div class="footer-widget links-widget style-two">
                <div class="h5 widget-title">Service</div>
                <div class="widget-content">
                  <ul class="user-links">
                    <li><a href="#/">Residential Moving</a></li>
                    <li><a href="#/">Furniture Assembly</a></li>
                    <li><a href="#/">Local Moving</a></li>
                    <li><a href="#/">Long-Distance Moving</a></li>
                    <li><a href="#/">Packing & Unpacking</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <!-- Footer Column -->
            <div class="footer-column style-two col-lg-3 col-md-6">
              <div class="footer-widget contact-widget">
                <div class="widget-content">
                  <ul class="social-info style-one">
                    <li>+629 555-0129</li>
                    <li>demo@example.com</li>
                  </ul>
                  <ul class="social-info">
                    <li>1901 Thornridge Cir. Shiloh <br>Hawaii 81063</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="footer-bottom">
          <div class="inner-container">
            <div class="upper-box">
              <div class="logo"><img src="images/logo3.png" alt=""></div>
              <ul class="footer-nav">
                <li><a href="#">Terms & Condition</a></li>
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">Contact us</a></li>
              </ul>
            </div>
            <div class="lower-box">
              <p class="copyright-text">© Copyright 2026 by Company.com | All Rights Reserved</p>
              <ul class="social-icon">
                <li>
                  <a href="#"><i class="fa-brands fa-facebook-f"></i></a>
                </li>
                <li>
                  <a href="#"><i class="fa-brands fa-twitter"></i></a>
                </li>
                <li>
                  <a href="#"><i class="fa-brands fa-linkedin-in"></i></a>
                </li>
                <li>
                  <a href="#"><i class="fa-brands fa-youtube"></i></a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </footer>
    <!--End Main Footer -->

  </div>
<!-- End Page Wrapper -->

<script src="js/jquery.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/wow.js"></script>
<script src="js/select2.min.js"></script>
<script src="js/appear.js"></script>
<script src="js/bxslider.js"></script>
<script src="js/mixitup.js"></script>
<script src="js/knob.js"></script>
<script src="js/swiper.min.js"></script>
<script src="js/aos.js"></script>
<script src="js/gsap.min.js"></script>
<script src="js/ScrollTrigger.min.js"></script>
<script src="js/splitType.js"></script>
<script src="js/gsap-scroll-smoother.js"></script>
<script src="js/gsap-scroll-to-plugin.js"></script>
<script src="js/SplitText.min.js"></script>
<script src="js/custom-gsap.js"></script>
<script src="js/script.js"></script>
<!-- form submit -->
<script src="js/jquery.validate.min.js"></script>
<script src="js/jquery.form.min.js"></script>
<script src="js/contact-form-script.js"></script>
</body>
</html>
