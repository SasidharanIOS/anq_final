<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Movingza - Movers & Packers PHP Template - 404</title>
  <link href="css/bootstrap.min.css" rel="stylesheet" />
  <link href="css/style.css" rel="stylesheet" />
  <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon" />
  <link rel="icon" href="images/favicon.png" type="image/x-icon" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>
<body>
<div class="page-wrapper">

  <div class="preloader"></div>

  <!-- 404 Section -->
  <section class="">
    <div class="auto-container pt-120 pb-70">
      <div class="row">
        <div class="col-xl-12">
          <div class="error-page__inner">
            <div class="error-page__title-box">
              <img src="images/resource/404.jpg" alt="">
              <div class="h3 error-page__sub-title">Page not found!</div>
            </div>
            <p class="error-page__text">Sorry we can't find that page! The page you are looking <br /> for
              was never existed.</p>
            <form class="error-page__form">
              <div class="error-page__form-input">
                <input type="search" placeholder="Search here">
                <button type="submit"><i class="lnr lnr-icon-magnifier"></i></button>
              </div>
            </form>
            <a href="index.php" class="theme-btn btn-style-four shop-now"><span class="btn-title">Back to Home</span></a>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!--End 404 Section -->

</div>
<!-- End Page Wrapper -->

<script src="js/jquery.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/wow.js"></script>
<script src="js/select2.min.js"></script>
<script src="js/appear.js"></script>
<script src="js/bxslider.js"></script>
<script src="js/mixitup.js"></script>
<script src="js/knob.js"></script>
<script src="js/swiper.min.js"></script>
<script src="js/aos.js"></script>
<script src="js/gsap.min.js"></script>
<script src="js/ScrollTrigger.min.js"></script>
<script src="js/splitType.js"></script>
<script src="js/gsap-scroll-smoother.js"></script>
<script src="js/gsap-scroll-to-plugin.js"></script>
<script src="js/SplitText.min.js"></script>
<script src="js/custom-gsap.js"></script>
<script src="js/script.js"></script>
<!-- form submit -->
<script src="js/jquery.validate.min.js"></script>
<script src="js/jquery.form.min.js"></script>
<script src="js/contact-form-script.js"></script>
</body>
</html>
