<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Movingza - Movers & Packers PHP Template | Home Page 02</title>
  <link href="css/bootstrap.min.css" rel="stylesheet" />
  <link href="css/style.css" rel="stylesheet" />
  <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon" />
  <link rel="icon" href="images/favicon.png" type="image/x-icon" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>
<body>
<div class="page-wrapper">

    <div class="preloader"></div>

    <!-- Back-to-top start -->
    <div class="back-to-top-wrapper">
      <button id="back_to_top" type="button" class="back-to-top-btn">
        <svg width="12" height="7" viewBox="0 0 12 7" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M11 6L6 1L1 6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
        </svg>
      </button>
    </div>
    <!-- Back-to-top start -->

    <!-- Main Header-->
    <header class="main-header header-style-two">
      <div class="outer-box">
        <div class="header-lower anim-fade-move" data-delay="0.25">
          <div class="inner-container">
            <!-- Main box -->
            <div class="main-box">
              <div class="logo-box">
                <div class="logo">
                  <a href="index.php"><img src="images/logo.png" alt="Logo" /></a>
                </div>
              </div>

            </div>
            <!--Nav Box-->
            <div class="nav-outer">
              <nav class="nav main-menu">
                <ul class="navigation">
  <li class="current dropdown">
    <a href="index.php">Home</a>
    <ul>
      <li><a href="index.php">Home 01</a></li>
      <li><a href="index-2.php">Home 02</a></li>
      <li><a href="index-3.php">Home 03</a></li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">Pages</a>
    <ul>
      <li><a href="page-about.php">About Us</a></li>
      <li class="dropdown"><a href="#">Team</a>
        <ul>
          <li><a href="page-team.php">Team Grid</a></li>
          <li><a href="page-team-details.php">Team Details</a></li>
        </ul>
      </li>
      <li><a href="page-pricing.php">Pricing Plan</a></li>
      <li><a href="page-testimonial.php">Testimonials</a></li>
      <li><a href="page-faq.php">Faq</a></li>
      <li class="dropdown"><a href="#">Shop</a>
        <ul>
          <li><a href="shop-products.php">Products</a></li>
          <li><a href="shop-products-sidebar.php">Products with Sidebar</a></li>
          <li><a href="shop-product-details.php">Product Details</a></li>
          <li><a href="shop-cart.php">Cart</a></li>
          <li><a href="shop-checkout.php">Checkout</a></li>
        </ul>
      </li>
      <li><a href="page-404.php">404</a></li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">Services</a>
    <ul>
      <li><a href="page-services.php">Services Grid</a></li>
      <li><a href="page-service-details.php">Services Details</a></li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">Projects</a>
    <ul>
      <li><a href="page-projects.php">Project Grid</a></li>
      <li><a href="page-project-details.php">Project Details</a></li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">Blog</a>
    <ul>
      <li><a href="news-grid.php">Blog Grid</a></li>
      <li><a href="news-details.php">Blog Details</a></li>
    </ul>
  </li>
  <li class=""><a href="page-contact.php">Contact</a></li>
</ul>
              </nav>
            </div>
            <div class="right-box">
              <button class="ui-btn search-btn">
                <i class="fa-solid fa-magnifying-glass"></i>
              </button>
              <a class="theme-btn btn-style-five" href="page-contact.php">
                <span class="btn-title">Let's Talk</span>
              </a>
              <!--Mobile Navigation Toggler-->
              <div class="mobile-nav-toggler">
                <span></span>
                <span></span>
                <span></span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Mobile Menu  -->
      <div class="mobile-menu">
        <div class="menu-backdrop"></div>
        <!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
        <nav class="menu-box">
          <div class="upper-box">
            <div class="nav-logo">
              <a href="index.php"><img src="images/logo2.png" alt="" /></a>
            </div>
            <div class="close-btn"><i class="icon fa fa-times"></i></div>
          </div>
          <ul class="navigation clearfix">
            <!--Keep This Empty / Menu will come through Javascript-->
          </ul>
          <ul class="contact-list-one">
            <li>
              <i class="icon fa-regular fa-envelope"></i>
              <span class="title">Send Email</span>
              <div class="text"><a href="mailto:needhelp@company.com">needhelp@company.com</a></div>
            </li>
          </ul>
          <ul class="social-links">
            <li>
              <a href="#"><i class="icon fab fa-twitter"></i></a>
            </li>
            <li>
              <a href="#"><i class="icon fab fa-facebook-f"></i></a>
            </li>
            <li>
              <a href="#"><i class="icon fab fa-pinterest-p"></i></a>
            </li>
            <li>
              <a href="#"><i class="icon fab fa-vimeo-v"></i></a>
            </li>
          </ul>
        </nav>
      </div>
      <!-- End Mobile Menu -->

      <!-- Header Search -->
      <div class="search-popup">
        <span class="search-back-drop"></span>
        <button class="close-search"><span class="fa fa-times"></span></button>

        <div class="search-inner">
          <form method="post" action="index.php">
            <div class="form-group">
              <input type="search" name="search-field" value="" placeholder="Search..." required="" />
              <button type="submit"><i class="fa fa-search"></i></button>
            </div>
          </form>
        </div>
      </div>
      <!-- End Header Search -->

      <!-- Sticky Header  -->
      <div class="sticky-header">
        <div class="auto-container">
          <div class="inner-container">
            <!--Logo-->
            <div class="logo">
              <a href="index.php"><img src="images/logo.png" alt=""></a>
            </div>

            <!--Right Col-->
            <div class="nav-outer">
              <!-- Main Menu -->
              <nav class="main-menu">
                <div class="navbar-collapse show collapse clearfix">
                  <ul class="navigation clearfix">
                    <!--Keep This Empty / Menu will come through Javascript-->
                  </ul>
                </div>
              </nav>
              <!-- Main Menu End-->

              <!--Mobile Navigation Toggler-->
              <div class="mobile-nav-toggler">
                <span></span>
                <span></span>
                <span></span>
              </div>
            </div>
            
            <a href="tel:+8801750050088" class="header-phone_box">
              <span class="icon"><i aria-hidden="true" class="fas fa-phone-alt"></i></span>
              <span class="info">
                Call Anytime
                <strong>+8801750050088</strong>
              </span>
            </a>
          </div>
        </div>
      </div>
      <!-- End Sticky Menu -->
    </header>
    <!--End Main Header -->
<!-- start banner-section -->
    <section class="banner-section-two">
      <div class="outer-box">
        <div class="row">
          <div class="content-column col-lg-7">
            <div class="inner-column">
              <div class="h1 banner-title">Moving your life with care precision and <img src="images/banner/banner2-1.png" alt=""> trust</div>
              <div class="text">Creating a compelling brand identity and marketing strategy for a moving company requires balancing trust reliability and professionalism</div>
              <div class="bottom-box">
                <a href="page-about.php" class="theme-btn btn-style-three">Discover More<i class="fa-light fa-arrow-up-right"></i></a>
                <div class="video-box">
                  <a href="https://www.youtube.com/watch?v=Lplq8RjQ0zU" data-fancybox="gallery" class="video-btn playbtnanim"><i class="fa-sharp fa-solid fa-play"></i></a>
                  <div class="title">Watch Video</div>
                </div>
              </div>
            </div>
          </div>
          <div class="image-column col-lg-5">
            <div class="inner-column">
              <div class="banner-two-slider-down swiper-container">
                <div class="swiper-wrapper">
                  <div class="swiper-slide">
                    <div class="image"><img src="images/banner/banner2-1.jpg" alt=""></div>
                  </div>
                  <div class="swiper-slide">
                    <div class="image"><img src="images/banner/banner2-2.jpg" alt=""></div>
                  </div>
                  <div class="swiper-slide">
                    <div class="image"><img src="images/banner/banner2-3.jpg" alt=""></div>
                  </div>
                  <div class="swiper-slide">
                    <div class="image"><img src="images/banner/banner2-4.jpg" alt=""></div>
                  </div>
                  <div class="swiper-slide">
                    <div class="image"><img src="images/banner/banner2-5.jpg" alt=""></div>
                  </div>
                  <div class="swiper-slide">
                    <div class="image"><img src="images/banner/banner2-6.jpg" alt=""></div>
                  </div>
                </div>
              </div>
              <div class="banner-two-slider-up swiper-container">
                <div class="swiper-wrapper">
                  <div class="swiper-slide">
                    <div class="image"><img src="images/banner/banner2-4.jpg" alt=""></div>
                  </div>
                  <div class="swiper-slide">
                    <div class="image"><img src="images/banner/banner2-5.jpg" alt=""></div>
                  </div>
                  <div class="swiper-slide">
                    <div class="image"><img src="images/banner/banner2-6.jpg" alt=""></div>
                  </div>
                  <div class="swiper-slide">
                    <div class="image"><img src="images/banner/banner2-1.jpg" alt=""></div>
                  </div>
                  <div class="swiper-slide">
                    <div class="image"><img src="images/banner/banner2-2.jpg" alt=""></div>
                  </div>
                  <div class="swiper-slide">
                    <div class="image"><img src="images/banner/banner2-3.jpg" alt=""></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- end banner-section -->
<!-- start about-section-two -->
    <section class="about-section-two">
      <div class="auto-container">
        <div class="row">
          <div class="image-column col-xl-6 col-lg-8 col-md-10">
            <div class="inner-column">
              <div class="image-box one">
                <div class="image"><img src="images/resource/about2-1.jpg" alt=""></div>
              </div>
              <div class="image-box two">
                <div class="image"><img src="images/resource/about2-2.jpg" alt=""></div>
              </div>
              <div class="funfact-box">
                <div class="counter-box">
                  <div class="count-box">
                    <span class="count-text" data-speed="3000" data-stop="25">0</span>
                    <span class="icon">+</span>
                  </div>
                  <div class="text">Years of <br>Experience</div>
                </div>
              </div>
            </div>
          </div>
          <div class="content-column col-xl-6 col-lg-10">
            <div class="inner-column">
              <div class="sec-title">
                <div class="h6 sub-title">About Us</div>
                <div class="h2 title">We provide best Moving solution <span>in City</span></div>
                <div class="text">The moving industry thrives on trust and reputation.Your visual identity and marketing should scream professional reliable, and caring at every touchpoint. In an industry where anxiety</div>
              </div>
              <ul class="list-style-one">
                <li>
                  <i class="icon fa-solid fa-check"></i>
                  <span>Certainty that the move will actually happen as planned</span>
                </li>
                <li>
                  <i class="icon fa-solid fa-check"></i>
                  <span>Professional management of complex logistics</span>
                </li>
                <li>
                  <i class="icon fa-solid fa-check"></i>
                  <span>Showing up on time, careful handling no hidden fees</span>
                </li>
                <li>
                  <i class="icon fa-solid fa-check"></i>
                  <span>Professional packing materials and techniques</span>
                </li>
              </ul>
              <div class="bottom-box">
                <a href="page-about.php" class="theme-btn btn-style-three">More About Us<i class="fa-light fa-arrow-up-right"></i></a>
                <div class="info-box">
                  <div class="image"><img src="images/resource/about1-3.png" alt=""></div>
                  <div class="info">
                    <div class="h5 name">Robert Milkwood</div>
                    <div class="designation">Founder</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- enc about-section-two -->
<!-- start services-section-three -->
    <section class="services-section-three">
      <div class="outer-box">
        <div class="auto-container">
          <div class="sec-title style-two text-center wow fadeInUp" data-wow-delay="200ms">
            <div class="h6 sub-title">Our Service</div>
            <div class="h2 title">Reliable Moving Services for <br>Homes <span>& Businesses</span></div>
          </div>
          <div class="default-tabs tabs-box">
            <!-- Tab Btns -->
            <div class="tab-btns tab-buttons wow fadeInUp" data-wow-delay="300ms">
              <div class="row">
                <div class="col-lg-3 col-md-6 ">
                  <button data-tab="#prod-residential" class="tab-btn active-btn">Residential Moving</button>
                </div>
                <div class="col-lg-3 col-md-6 ">
                  <button data-tab="#prod-long-distance" class="tab-btn">Long-Distance Moving</button>
                </div>
                <div class="col-lg-3 col-md-6 ">
                  <button data-tab="#prod-furniture" class="tab-btn">Furniture Disassembly</button>
                </div>
                <div class="col-lg-3 col-md-6 ">
                  <button data-tab="#prod-loading" class="tab-btn">Loading & Unloading</button>
                </div>
              </div>
            </div>

            <!-- Tabs Container -->
            <div class="tabs-content">

              <!-- Tab -->
              <div class="tab active-tab wow fadeInUp" data-wow-delay="400ms" id="prod-residential">
                <div class="tab-inner-content">
                  <div class="service-block-four">
                    <div class="inner-block">
                      <div class="row">
                        <div class="image-box col-lg-6">
                          <div class="image"><img src="images/resource/service4-1.jpg" alt=""></div>
                        </div>
                        <div class="content-box col-lg-6">
                          <div class="inner-box">
                            <div class="h3 title"><a href="page-service-details.php">Residential Moving</a></div>
                            <div class="text">We've helped thousands of families, couples, and individuals transition between homes across [Region]. We've learned that a successful move isn't measured by speed alone</div>
                            <div class="list-style-box">
                              <ul class="list-style-one">
                                <li>
                                  <i class="icon fa-solid fa-check"></i>
                                  <span>Packing supplies</span>
                                </li>
                                <li>
                                  <i class="icon fa-solid fa-check"></i>
                                  <span>Professional movers</span>
                                </li>
                                <li>
                                  <i class="icon fa-solid fa-check"></i>
                                  <span>Utility connection fees</span>
                                </li>
                              </ul>
                              <ul class="list-style-one">
                                <li>
                                  <i class="icon fa-solid fa-check"></i>
                                  <span>Moving plants</span>
                                </li>
                                <li>
                                  <i class="icon fa-solid fa-check"></i>
                                  <span>Before unpacking</span>
                                </li>
                                <li>
                                  <i class="icon fa-solid fa-check"></i>
                                  <span>Document valuables</span>
                                </li>
                              </ul>
                            </div>
                            <a href="page-service-details.php" class="theme-btn btn-style-three">See All Article<i class="fa-light fa-arrow-up-right"></i></a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Tab -->
              <div class="tab" id="prod-long-distance">
                <div class="tab-inner-content">
                  <div class="service-block-four">
                    <div class="inner-block">
                      <div class="row">
                        <div class="image-box col-lg-6">
                          <div class="image"><img src="images/resource/service4-1.jpg" alt=""></div>
                        </div>
                        <div class="content-box col-lg-6">
                          <div class="inner-box">
                            <div class="h3 title"><a href="page-service-details.php">Long-Distance Moving</a></div>
                            <div class="text">We've helped thousands of families, couples, and individuals transition between homes across [Region]. We've learned that a successful move isn't measured by speed alone</div>
                            <div class="list-style-box">
                              <ul class="list-style-one">
                                <li>
                                  <i class="icon fa-solid fa-check"></i>
                                  <span>Packing supplies</span>
                                </li>
                                <li>
                                  <i class="icon fa-solid fa-check"></i>
                                  <span>Professional movers</span>
                                </li>
                                <li>
                                  <i class="icon fa-solid fa-check"></i>
                                  <span>Utility connection fees</span>
                                </li>
                              </ul>
                              <ul class="list-style-one">
                                <li>
                                  <i class="icon fa-solid fa-check"></i>
                                  <span>Moving plants</span>
                                </li>
                                <li>
                                  <i class="icon fa-solid fa-check"></i>
                                  <span>Before unpacking</span>
                                </li>
                                <li>
                                  <i class="icon fa-solid fa-check"></i>
                                  <span>Document valuables</span>
                                </li>
                              </ul>
                            </div>
                            <a href="page-service-details.php" class="theme-btn btn-style-three">See All Article<i class="fa-light fa-arrow-up-right"></i></a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Tab -->
              <div class="tab" id="prod-furniture">
                <div class="tab-inner-content">
                  <div class="service-block-four">
                    <div class="inner-block">
                      <div class="row">
                        <div class="image-box col-lg-6">
                          <div class="image"><img src="images/resource/service4-1.jpg" alt=""></div>
                        </div>
                        <div class="content-box col-lg-6">
                          <div class="inner-box">
                            <div class="h3 title"><a href="page-service-details.php">Furniture Disassembly</a></div>
                            <div class="text">We've helped thousands of families, couples, and individuals transition between homes across [Region]. We've learned that a successful move isn't measured by speed alone</div>
                            <div class="list-style-box">
                              <ul class="list-style-one">
                                <li>
                                  <i class="icon fa-solid fa-check"></i>
                                  <span>Packing supplies</span>
                                </li>
                                <li>
                                  <i class="icon fa-solid fa-check"></i>
                                  <span>Professional movers</span>
                                </li>
                                <li>
                                  <i class="icon fa-solid fa-check"></i>
                                  <span>Utility connection fees</span>
                                </li>
                              </ul>
                              <ul class="list-style-one">
                                <li>
                                  <i class="icon fa-solid fa-check"></i>
                                  <span>Moving plants</span>
                                </li>
                                <li>
                                  <i class="icon fa-solid fa-check"></i>
                                  <span>Before unpacking</span>
                                </li>
                                <li>
                                  <i class="icon fa-solid fa-check"></i>
                                  <span>Document valuables</span>
                                </li>
                              </ul>
                            </div>
                            <a href="page-service-details.php" class="theme-btn btn-style-three">See All Article<i class="fa-light fa-arrow-up-right"></i></a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Tab -->
              <div class="tab" id="prod-loading">
                <div class="tab-inner-content">
                  <div class="service-block-four">
                    <div class="inner-block">
                      <div class="row">
                        <div class="image-box col-lg-6">
                          <div class="image"><img src="images/resource/service4-1.jpg" alt=""></div>
                        </div>
                        <div class="content-box col-lg-6">
                          <div class="inner-box">
                            <div class="h3 title"><a href="page-service-details.php">Loading & Unloading</a></div>
                            <div class="text">We've helped thousands of families, couples, and individuals transition between homes across [Region]. We've learned that a successful move isn't measured by speed alone</div>
                            <div class="list-style-box">
                              <ul class="list-style-one">
                                <li>
                                  <i class="icon fa-solid fa-check"></i>
                                  <span>Packing supplies</span>
                                </li>
                                <li>
                                  <i class="icon fa-solid fa-check"></i>
                                  <span>Professional movers</span>
                                </li>
                                <li>
                                  <i class="icon fa-solid fa-check"></i>
                                  <span>Utility connection fees</span>
                                </li>
                              </ul>
                              <ul class="list-style-one">
                                <li>
                                  <i class="icon fa-solid fa-check"></i>
                                  <span>Moving plants</span>
                                </li>
                                <li>
                                  <i class="icon fa-solid fa-check"></i>
                                  <span>Before unpacking</span>
                                </li>
                                <li>
                                  <i class="icon fa-solid fa-check"></i>
                                  <span>Document valuables</span>
                                </li>
                              </ul>
                            </div>
                            <a href="page-service-details.php" class="theme-btn btn-style-three">View Details<i class="fa-light fa-arrow-up-right"></i></a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
          <div class="bottom-box">
            <div class="image-box">
              <div class="image"><img src="images/resource/service4-2.jpg" alt=""></div>
              <div class="icon"><img src="images/icons/shape-2.png" alt=""></div>
            </div>
            <div class="info">
              <div class="h4 title">Distinct Solutions for Every Moving</div>
              <div class="text">Global Moving Solutions Provider Since 1995</div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- end services-section-three -->
<!-- start why-choose-us-section-two -->
    <section class="why-choose-us-section-two pb-110">
      <div class="auto-container">
        <div class="sec-title text-center">
          <div class="h6 sub-title">Why Choose Us</div>
          <div class="h2 title">Why Choose Our <span>Moving Experts?</span></div>
          <div class="text">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout </div>
        </div>
        <div class="row">
          <div class="left-side col-xl-4 col-md-6">
            <div class="why-choose-us-block">
              <div class="inner-block">
                <div class="icon"><img src="images/icons/wcu2-1.png" alt=""></div>
                <div class="h4 title">Safe Handling Equipment</div>
                <div class="text">But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete</div>
              </div>
            </div>
            <div class="why-choose-us-block">
              <div class="inner-block">
                <div class="icon"><img src="images/icons/wcu2-2.png" alt=""></div>
                <div class="h4 title">Affordable Pricing</div>
                <div class="text">But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete</div>
              </div>
            </div>
          </div>
          <div class="image-column col-xl-4">
            <div class="inner-column">
              <div class="image wow fadeInUp" data-wow-delay="400ms"><img src="images/resource/wcu2-1.png" alt=""></div>
            </div>
          </div>
          <div class="right-side col-xl-4 col-md-6">
            <div class="why-choose-us-block">
              <div class="inner-block">
                <div class="icon"><img src="images/icons/wcu2-3.png" alt=""></div>
                <div class="h4 title">Reliable & On-Time Service</div>
                <div class="text">But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete</div>
              </div>
            </div>
            <div class="why-choose-us-block">
              <div class="inner-block">
                <div class="icon"><img src="images/icons/wcu2-4.png" alt=""></div>
                <div class="h4 title">Customized Solutions</div>
                <div class="text">But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- end why-choose-us-section-two -->
<!-- start marquee-section -->
    <section class="marquee-section">
      <div class="marquee">
        <div class="marquee-group">
          <div class="text" data-text="Licensed Electricians • 24/7 Emergency Service • 100% Safety Guaranteed • Fast Turnaround • Transparent Pricing">Licensed Electricians • 24/7 Emergency Service • 100% Safety Guaranteed • Fast Turnaround • Transparent Pricing</div>
          <div class="text" data-text="Licensed Electricians • 24/7 Emergency Service • 100% Safety Guaranteed • Fast Turnaround • Transparent Pricing">Licensed Electricians • 24/7 Emergency Service • 100% Safety Guaranteed • Fast Turnaround • Transparent Pricing</div>
        </div>
      </div>
    </section>
    <!-- end marquee-section -->
<!-- start project-section -->
    <section class="project-section pb-0">
      <div class="auto-container">
        <div class="sec-title-box">
          <div class="sec-title">
            <div class="h6 sub-title">Latest Projects</div>
            <div class="h2 title">Our Most Recent Moving <br><span>Projects Portfolio</span></div>
          </div>
          <div class="arrow-box">
            <div class="project-slider-prev"><i class="fa-solid fa-arrow-left"></i></div>
            <div class="project-slider-next"><i class="fa-solid fa-arrow-right"></i></div>
          </div>
        </div>
      </div>
      <div class="outer-box">
        <div class="project-one-slider swiper-container pb-0 wow fadeInUp" data-wow-delay="400ms">
          <div class="swiper-wrapper align-items-center">
            <div class="project-block swiper-slide">
              <div class="inner-block">
                <div class="image"><img src="images/resource/project1-1.jpg" alt=""></div>
                <div class="content">
                  <div class="catagory">Residential</div>
                  <div class="h4 title-box"><a href="page-project-details.php" class="title">Household Move</a><a class="btn-more" href="page-project-details.php"><i class="fa-solid fa-arrow-right"></i></a></div>
                </div>
              </div>
            </div>
            <div class="project-block swiper-slide">
              <div class="inner-block style-two">
                <div class="image"><img src="images/resource/project1-2.jpg" alt=""></div>
                <div class="content">
                  <div class="catagory">Residential</div>
                  <div class="h4 title-box"><a href="page-project-details.php" class="title">Project Solutions</a><a class="btn-more" href="page-project-details.php"><i class="fa-solid fa-arrow-right"></i></a></div>
                </div>
              </div>
            </div>
            <div class="project-block swiper-slide">
              <div class="inner-block">
                <div class="image"><img src="images/resource/project1-3.jpg" alt=""></div>
                <div class="content">
                  <div class="catagory">Residential</div>
                  <div class="h4 title-box"><a href="page-project-details.php" class="title">Home Move</a><a class="btn-more" href="page-project-details.php"><i class="fa-solid fa-arrow-right"></i></a></div>
                </div>
              </div>
            </div>
            <div class="project-block swiper-slide">
              <div class="inner-block style-two">
                <div class="image"><img src="images/resource/project1-4.jpg" alt=""></div>
                <div class="content">
                  <div class="catagory">Residential</div>
                  <div class="h4 title-box"><a href="page-project-details.php" class="title">Moving Service</a><a class="btn-more" href="page-project-details.php"><i class="fa-solid fa-arrow-right"></i></a></div>
                </div>
              </div>
            </div>
            <div class="project-block swiper-slide">
              <div class="inner-block">
                <div class="image"><img src="images/resource/project1-1.jpg" alt=""></div>
                <div class="content">
                  <div class="catagory">Residential</div>
                  <div class="h4 title-box"><a href="page-project-details.php" class="title">Household Move</a><a class="btn-more" href="page-project-details.php"><i class="fa-solid fa-arrow-right"></i></a></div>
                </div>
              </div>
            </div>
            <div class="project-block swiper-slide">
              <div class="inner-block style-two">
                <div class="image"><img src="images/resource/project1-2.jpg" alt=""></div>
                <div class="content">
                  <div class="catagory">Residential</div>
                  <div class="h4 title-box"><a href="page-project-details.php" class="title">Project Solutions</a><a class="btn-more" href="page-project-details.php"><i class="fa-solid fa-arrow-right"></i></a></div>
                </div>
              </div>
            </div>
            <div class="project-block swiper-slide">
              <div class="inner-block">
                <div class="image"><img src="images/resource/project1-3.jpg" alt=""></div>
                <div class="content">
                  <div class="catagory">Residential</div>
                  <div class="h4 title-box"><a href="page-project-details.php" class="title">Home Move</a><a class="btn-more" href="page-project-details.php"><i class="fa-solid fa-arrow-right"></i></a></div>
                </div>
              </div>
            </div>
            <div class="project-block swiper-slide">
              <div class="inner-block style-two">
                <div class="image"><img src="images/resource/project1-4.jpg" alt=""></div>
                <div class="content">
                  <div class="catagory">Residential</div>
                  <div class="h4 title-box"><a href="page-project-details.php" class="title">Moving Service</a><a class="btn-more" href="page-project-details.php"><i class="fa-solid fa-arrow-right"></i></a></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- end project-section -->
<!-- start faq-section-two -->
    <section class="faq-section-two">
      <div class="outer-box pb-100">
        <div class="shape-1 bounce-y"><img src="images/icons/shape-3.png" alt=""></div>
        <div class="auto-container">
          <div class="row">
            <div class="content-column col-xl-5">
              <div class="inner-column">
                <div class="sec-title light">
                  <div class="h6 sub-title">FAQS</div>
                  <div class="h2 title">Answers Most Common <span>Queries!</span></div>
                </div>
                <div class="info-box one">
                  <div class="icon"><i class="icon fa-solid fa-check"></i></div>
                  <div class="info">
                    <div class="h5 title">Fully Insured & Secure</div>
                    <div class="text">But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain</div>
                  </div>
                </div>
                <div class="info-box">
                  <div class="icon"><i class="icon fa-solid fa-check"></i></div>
                  <div class="info">
                    <div class="h5 title">Certified and Awarded</div>
                    <div class="text">But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain</div>
                  </div>
                </div>
              </div>
            </div>
            <div class="faq-column col-xl-7">
              <div class="inner-column">
                <div class="faq-box">
                  <div class="inner-box">
                    <ul class="accordion-box">
                      <!--Block-->
                      <li class="accordion block">
                        <div class="acc-btn ">What should I do before movers arrive?
                          <i class="icon fa-solid fa-chevron-down"></i>
                        </div>
                        <div class="acc-content">
                          <div class="content">
                            <div class="text">On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire</div>
                          </div>
                        </div>
                      </li>
                      <!--Block-->
                      <li class="accordion block active-block">
                        <div class="acc-btn active">Should I pack myself or pay for packing services?
                          <i class="icon fa-solid fa-chevron-down"></i>
                        </div>
                        <div class="acc-content current">
                          <div class="content">
                            <div class="text">On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire</div>
                          </div>
                        </div>
                      </li>
                      <!--Block-->
                      <li class="accordion block">
                        <div class="acc-btn">How long do I have to file a damage claim?
                          <i class="icon fa-solid fa-chevron-down"></i>
                        </div>
                        <div class="acc-content">
                          <div class="content">
                            <div class="text">On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire</div>
                          </div>
                        </div>
                      </li>
                      <!--Block-->
                      <li class="accordion block">
                        <div class="acc-btn">How can I leave an effective review?
                          <i class="icon fa-solid fa-chevron-down"></i>
                        </div>
                        <div class="acc-content">
                          <div class="content">
                            <div class="text">On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire</div>
                          </div>
                        </div>
                      </li>
                      <!--Block-->
                      <li class="accordion block">
                        <div class="acc-btn">How can I spot a moving scam?
                          <i class="icon fa-solid fa-chevron-down"></i>
                        </div>
                        <div class="acc-content">
                          <div class="content">
                            <div class="text">On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire</div>
                          </div>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- end faq-section-two -->
<!-- start why-choose-us-section -->
    <section class="why-choose-us-section-three">
      <div class="auto-container">
        <div class="sec-title">
          <div class="row">
            <div class="col-lg-4">
              <div class="h6 sub-title">Our Benefits</div>
            </div>
            <div class="col-lg-8">
              <div class="h2 title">We Don't Just Move We Deliver Peace <span>of Mind</span></div>
            </div>
          </div>
        </div>
        <div class="row gx-4">
          <div class="why-choose-us-block-three col-lg-4 col-md-6">
            <div class="inner-block wow fadeInUp" data-wow-delay="200ms">
              <div class="content-box">
                <div class="inner-box">
                  <a class="icon" href="page-project-details.php"><i class="fa-solid fa-arrow-right"></i></a>
                  <div class="image one"><img src="images/resource/wcu3-1.jpg" alt=""></div>
                  <div class="content">
                    <div class="h4 title">Efficient Solutions</div>
                    <div class="text">It is a long established fact that a reader will be distracted readable content</div>
                  </div>
                </div>
              </div>
              <div class="funfact-box">
                <div class="inner-box">
                  <div class="h2 count-box"><span class="count-text" data-speed="3000" data-stop="95">0</span>%</div>
                  <div class="h5 title">Customer <br>satisfaction rate</div>
                </div>
              </div>
            </div>
          </div>
          <div class="image-column col-lg-4 col-md-6">
            <div class="inner-column wow fadeInUp" data-wow-delay="400ms">
              <div class="image"><img src="images/resource/wcu3-3.jpg" alt=""></div>
              <div class="logo"><img src="images/icons/wcu3-4.png" alt=""></div>
            </div>
          </div>
          <div class="why-choose-us-block-three col-lg-4 col-md-6">
            <div class="inner-block wow fadeInUp" data-wow-delay="600ms">
              <div class="author-info">
                <div class="image"><img src="images/resource/wcu3-4.png" alt=""></div>
                <div class="text">Skilled Hands, Honest Hearts</div>
              </div>
              <div class="content-box">
                <div class="inner-box">
                  <a class="icon" href="page-project-details.php"><i class="fa-solid fa-arrow-right"></i></a>
                  <div class="image two"><img src="images/resource/wcu3-2.jpg" alt=""></div>
                  <div class="content">
                    <div class="h4 title">Advanced Equipment</div>
                    <div class="text">It is a long established fact that a reader will be distracted by the readable content</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- end why-choose-us-section -->
<!-- start working-section-two -->
    <section class="working-section-two">
      <div class="outer-box">
        <div class="auto-container">
          <div class="sec-title style-two text-center">
            <div class="h6 sub-title">How It  Works</div>
            <div class="h2 title">Simple Process for a <br><span>Smooth Move</span></div>
          </div>
          <div class="working-outer">
            <div class="working-block-two">
              <div class="inner-block">
                <div class="icon-box">
                  <div class="icon"><img src="images/icons/work2-1.png" alt=""></div>
                  <div class="number">1</div>
                </div>
                <div class="h4 title">Request a Free Quote</div>
                <div class="text">In a free hour, when our power of choice is untrammelled and </div>
              </div>
            </div>
            <div class="shape-1"><img src="images/icons/shape-4.png" alt=""></div>
            <div class="working-block-two">
              <div class="inner-block">
                <div class="icon-box">
                  <div class="icon"><img src="images/icons/work2-2.png" alt=""></div>
                  <div class="number">2</div>
                </div>
                <div class="h4 title">Move Your Items Safely</div>
                <div class="text">In a free hour, when our power of choice is untrammelled and </div>
              </div>
            </div>
            <div class="shape-1"><img src="images/icons/shape-4.png" alt=""></div>
            <div class="working-block-two">
              <div class="inner-block">
                <div class="icon-box">
                  <div class="icon"><img src="images/icons/work2-3.png" alt=""></div>
                  <div class="number">3</div>
                </div>
                <div class="h4 title">Unload & Set Up</div>
                <div class="text">In a free hour, when our power of choice is untrammelled and </div>
              </div>
            </div>
          </div>
          <div class="bottom-box">
            <div class="inner-box">
              <div class="h5 title">Let's Request a Schedule For Free quote</div>
              <a href="page-contact.php" class="theme-btn btn-style-three">Get In Touch<i class="fa-light fa-arrow-up-right"></i></a>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- end working-section-two -->
<!-- start team-section-three -->
    <section class="team-section-two pb-120">
      <div class="auto-container">
        <div class="sec-title-box">
          <div class="sec-title">
            <div class="h6 sub-title">Our Experts</div>
            <div class="h2 title">Dedicated Professionals <br>Behind <span>Your Move</span></div>
          </div>
          <a href="page-team.php" class="theme-btn btn-style-three">View All Experts<i class="fa-light fa-arrow-up-right"></i></a>
        </div>
        <div class="row">
          <div class="team-block-two col-xl-3 col-sm-6 wow fadeInUp" data-wow-delay="200ms">
            <div class="inner-block">
              <div class="images-box">
                <div class="image">
                  <img src="images/resource/team2-1.jpg" alt="">
                  <img src="images/resource/team2-1.jpg" alt="">
                </div>
                <div class="shape-1"><img src="images/icons/shape-5.png" alt=""></div>
              </div>
              <div class="content-box">
                <div class="inner-box">
                  <div class="socials">
                    <i class="fa fa-plus"></i>
                    <ul class="social-links">
                      <li><a aria-label="facebook" href="#"><i class="fab fa-facebook"></i></a></li>
                      <li><a aria-label="twitter" href="#"><i class="fab fa-twitter"></i></a></li>
                      <li><a aria-label="instagram" href="#"><i class="fab fa-instagram"></i></a></li>
                    </ul>
                  </div>
                  <div class="author-info">
                    <div class="inner-info">
                      <div class="h4 name"><a href="page-team-details.php">Guy Hawkins</a></div>
                      <div class="designation">Senior Carpentor</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="team-block-two col-xl-3 col-sm-6 wow fadeInUp" data-wow-delay="300ms">
            <div class="inner-block">
              <div class="images-box">
                <div class="image">
                  <img src="images/resource/team2-2.jpg" alt="">
                  <img src="images/resource/team2-2.jpg" alt="">
                </div>
                <div class="shape-1"><img src="images/icons/shape-5.png" alt=""></div>
              </div>
              <div class="content-box">
                <div class="inner-box">
                  <div class="socials">
                    <i class="fa fa-plus"></i>
                    <ul class="social-links">
                      <li><a aria-label="facebook" href="#"><i class="fab fa-facebook"></i></a></li>
                      <li><a aria-label="twitter" href="#"><i class="fab fa-twitter"></i></a></li>
                      <li><a aria-label="instagram" href="#"><i class="fab fa-instagram"></i></a></li>
                    </ul>
                  </div>
                  <div class="author-info">
                    <div class="inner-info">
                      <div class="h4 name"><a href="page-team-details.php">Jacob Jones</a></div>
                      <div class="designation">Manager</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="team-block-two col-xl-3 col-sm-6 wow fadeInUp" data-wow-delay="400ms">
            <div class="inner-block">
              <div class="images-box">
                <div class="image">
                  <img src="images/resource/team2-3.jpg" alt="">
                  <img src="images/resource/team2-3.jpg" alt="">
                </div>
                <div class="shape-1"><img src="images/icons/shape-5.png" alt=""></div>
              </div>
              <div class="content-box">
                <div class="inner-box">
                  <div class="socials">
                    <i class="fa fa-plus"></i>
                    <ul class="social-links">
                      <li><a aria-label="facebook" href="#"><i class="fab fa-facebook"></i></a></li>
                      <li><a aria-label="twitter" href="#"><i class="fab fa-twitter"></i></a></li>
                      <li><a aria-label="instagram" href="#"><i class="fab fa-instagram"></i></a></li>
                    </ul>
                  </div>
                  <div class="author-info">
                    <div class="inner-info">
                      <div class="h4 name"><a href="page-team-details.php">Kristin Watson</a></div>
                      <div class="designation">Carpentor</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="team-block-two col-xl-3 col-sm-6 wow fadeInUp" data-wow-delay="500ms">
            <div class="inner-block">
              <div class="images-box">
                <div class="image">
                  <img src="images/resource/team2-4.jpg" alt="">
                  <img src="images/resource/team2-4.jpg" alt="">
                </div>
                <div class="shape-1"><img src="images/icons/shape-5.png" alt=""></div>
              </div>
              <div class="content-box">
                <div class="inner-box">
                  <div class="socials">
                    <i class="fa fa-plus"></i>
                    <ul class="social-links">
                      <li><a aria-label="facebook" href="#"><i class="fab fa-facebook"></i></a></li>
                      <li><a aria-label="twitter" href="#"><i class="fab fa-twitter"></i></a></li>
                      <li><a aria-label="instagram" href="#"><i class="fab fa-instagram"></i></a></li>
                    </ul>
                  </div>
                  <div class="author-info">
                    <div class="inner-info">
                      <div class="h4 name"><a href="page-team-details.php">Bessie Cooper</a></div>
                      <div class="designation">Founder</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- end team-section-three -->
<!-- start testimonial-section-two -->
    <section class="testimonial-section-two">
      <div class="outer-box">
        <div class="auto-container">
          <div class="sec-title text-center light">
            <div class="h6 sub-title">Testimonial</div>
            <div class="h2 title">The Best Customers Says <br>About <span>Our Action</span></div>
          </div>
        </div>
        <div class="outer-container">
          <div class="testimonial-two-slider swiper-container pb-0 wow fadeInUp" data-wow-delay="400ms">
            <div class="swiper-wrapper">
              <div class="testimonial-block-two swiper-slide">
                <div class="inner-block">
                  <div class="qoute-icon"><img src="images/icons/qute2-1.png" alt=""></div>
                  <div class="author-info">
                    <div class="image"><img src="images/resource/testi2-1.jpg" alt=""></div>
                    <div class="info">
                      <div class="h5 name">Jenny Wilson</div>
                      <div class="designation">Designer</div>
                    </div>
                  </div>
                  <div class="text">From the very first phone call, the team was professional, polite, and extremely organized They arrived on time, packed everything carefully and handled our furniture</div>
                  <div class="rating">
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                  </div>
                </div>
              </div>
              <div class="testimonial-block-two swiper-slide">
                <div class="inner-block">
                  <div class="qoute-icon"><img src="images/icons/qute2-1.png" alt=""></div>
                  <div class="author-info">
                    <div class="image"><img src="images/resource/testi2-2.jpg" alt=""></div>
                    <div class="info">
                      <div class="h5 name">Guy Hawkins</div>
                      <div class="designation">Designer</div>
                    </div>
                  </div>
                  <div class="text">Moving can be stressful, but this company made the entire process smooth and worry-free. The crew was friendly, hardworking, and incredibly efficient They</div>
                  <div class="rating">
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                  </div>
                </div>
              </div>
              <div class="testimonial-block-two swiper-slide">
                <div class="inner-block">
                  <div class="qoute-icon"><img src="images/icons/qute2-1.png" alt=""></div>
                  <div class="author-info">
                    <div class="image"><img src="images/resource/testi2-3.jpg" alt=""></div>
                    <div class="info">
                      <div class="h5 name">Jacob Jones</div>
                      <div class="designation">Designer</div>
                    </div>
                  </div>
                  <div class="text">We were impressed by how well-organized and professional the team was. They arrived fully prepared, packed everything securely, and delivered our belongings on time</div>
                  <div class="rating">
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                  </div>
                </div>
              </div>
              <div class="testimonial-block-two swiper-slide">
                <div class="inner-block">
                  <div class="qoute-icon"><img src="images/icons/qute2-1.png" alt=""></div>
                  <div class="author-info">
                    <div class="image"><img src="images/resource/testi2-4.jpg" alt=""></div>
                    <div class="info">
                      <div class="h5 name">Wade Warren</div>
                      <div class="designation">Designer</div>
                    </div>
                  </div>
                  <div class="text">From the very first phone call, the team was professional, polite, and extremely organized They arrived on time, packed everything carefully and handled our furniture</div>
                  <div class="rating">
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                  </div>
                </div>
              </div>
              <div class="testimonial-block-two swiper-slide">
                <div class="inner-block">
                  <div class="qoute-icon"><img src="images/icons/qute2-1.png" alt=""></div>
                  <div class="author-info">
                    <div class="image"><img src="images/resource/testi2-2.jpg" alt=""></div>
                    <div class="info">
                      <div class="h5 name">Guy Hawkins</div>
                      <div class="designation">Designer</div>
                    </div>
                  </div>
                  <div class="text">Moving can be stressful, but this company made the entire process smooth and worry-free. The crew was friendly, hardworking, and incredibly efficient They</div>
                  <div class="rating">
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                  </div>
                </div>
              </div>
            </div>
            <div class="testimonial-two-dots"></div>
          </div>
        </div>
      </div>
    </section>
    <!-- end testimonial-section-two -->
<!-- start map-section -->
    <section class="map-section">
      <div class="auto-container">
        <div class="sec-title text-center">
          <div class="h6 sub-title">Our Locations</div>
          <div class="h2 title">At every point your moving problem <br>needs us — <span>we're there</span></div>
        </div>
        <div class="row">
          <div class="map-block col-lg-12">
            <div class="image"><img src="images/resource/map1-1.png" alt=""></div>
            <div class="location-box one">
              <div class="content">Malaysia</div>
              <div class="dot"></div>
            </div>
            <div class="location-box two">
              <div class="content">Japan</div>
              <div class="dot"></div>
            </div>
            <div class="location-box three">
              <div class="content">Australia</div>
              <div class="dot"></div>
            </div>
            <div class="location-box four">
              <div class="content">Singapore</div>
              <div class="dot"></div>
            </div>
            <div class="location-box five">
              <div class="content">United States</div>
              <div class="dot"></div>
            </div>
            <div class="location-box six">
              <div class="content">North America</div>
              <div class="dot"></div>
            </div>
            <div class="location-box seven">
              <div class="content">Saudi Arabia</div>
              <div class="dot"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- end map-section -->
<!-- Funfact Section -->
    <section class="funfact-section pt-0">
      <div class="h6 funfact-title style-two"><span>Our Experience Speaks for Itself</span></div>
      <div class="container">
        <div class="inner-row">
          <div class="funfact-block">
            <div class="inner-block">
              <div class="text">Successful Moves <br>Completed</div>
              <div class="h3 count-box"><span class="count-text" data-speed="3000" data-stop="1500">0</span>+</div>
            </div>
          </div>
          <div class="funfact-block">
            <div class="inner-block">
              <div class="text">Customer <br>Satisfaction Rate</div>
              <div class="h3 count-box"><span class="count-text" data-speed="3000" data-stop="98">0</span>%</div>
            </div>
          </div>
          <div class="funfact-block">
            <div class="inner-block">
              <div class="text">Local & Long-Distance <br>Routes Served</div>
              <div class="h3 count-box"><span class="count-text" data-speed="3000" data-stop="4.9">0</span>/5</div>
            </div>
          </div>
          <div class="funfact-block">
            <div class="inner-block">
              <div class="text">Trained & <br>Professional Movers</div>
              <div class="h3 count-box"><span class="count-text" data-speed="3000" data-stop="50">0</span>+</div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- End Funfact Section -->
<!-- start contact-section -->
    <section class="contact-section">
      <div class="outer-box">
        <div class="row">
          <div class="form-column col-xl-5">
            <div class="inner-column">
              <div class="sec-title style-two">
                <div class="h6 sub-title">Contact Us</div>
                <div class="h2 title">connect with us</div>
              </div>
              <div class="form-box">
                <div class="inner-box">
                  <form action="#">
                    <div class="row gx-3">
                      <div class="col-sm-6 wow fadeInUp animated" data-wow-delay=".2s">
                        <div class="form-clt">
                          <input type="text" name="name" id="name" placeholder="Full Name" required="">
                        </div>
                      </div>
                      <div class="col-sm-6 wow fadeInUp animated" data-wow-delay=".4s">
                        <div class="form-clt">
                          <input type="email" name="email" id="email" placeholder="Email Address">
                        </div>
                      </div>
                      <div class="col-sm-6 wow fadeInUp animated" data-wow-delay=".2s">
                        <div class="form-clt">
                          <input type="text" name="phone" id="phone" placeholder="Phone Number">
                        </div>
                      </div>
                      <div class="col-sm-6 wow fadeInUp animated" data-wow-delay=".2s">
                        <div class="form-clt">
                          <select>
                            <option selected="" data-value="I would like to discussed">Move Type</option>
                            <option data-value="Household Move">Household Move</option>
                            <option data-value="Residential Move">Residential Move</option>
                            <option data-value="Project Solutions">Project Solutions</option>
                          </select>
                        </div>
                      </div>
                      <div class="col-sm-12 wow fadeInUp animated" data-wow-delay=".2s">
                        <div class="form-clt">
                          <textarea name="form_message" class="required" placeholder="Write Message"></textarea>
                        </div>
                      </div>
                      <div class="col-sm-12 wow fadeInUp animated" data-wow-delay=".2s">
                        <button class="theme-btn btn-style-three" type="submit">Submit Now<i class="fa-light fa-arrow-up-right"></i></button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
          <div class="image-column col-xl-7">
            <div class="inner-column">
              <div class="bg-image"><img src="images/resource/contact2-1.jpg" alt=""></div>
              <div class="content">
                <a class="video-box" href="https://www.youtube.com/watch?v=hddwAIXbKZo" data-fancybox="gallery" data-caption="">
                  <div class="icon"><img src="images/icons/contact2-1.png" alt=""></div>
                  <i class="fa-solid fa-play"></i>
                </a>
                <div class="h2 title">Providing Best quality <br>Moving Services</div>
                <div class="feature-box">
                  <div class="inner-box">
                    <div class="feature">
                      <i class="fa-solid fa-arrow-right"></i>
                      <span>One Destination</span>
                    </div>
                    <div class="feature">
                      <i class="fa-solid fa-arrow-right"></i>
                      <span>Long-Distance</span>
                    </div>
                    <div class="feature">
                      <i class="fa-solid fa-arrow-right"></i>
                      <span>Local Move</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- end contact-section -->
<!-- start blog-section -->
    <section class="blog-section">
      <div class="auto-container">
        <div class="sec-title-box">
          <div class="sec-title">
            <div class="h6 sub-title">Our Blog</div>
            <div class="h2 title">Check out latest <br>news <span>update & articles</span></div>
          </div>
          <a href="news-grid.php" class="theme-btn btn-style-three">See All Article<i class="fa-light fa-arrow-up-right"></i></a>
        </div>
        <div class="row gx-4">
          <div class="blog-block col-xl-4 col-md-6">
            <div class="inner-block">
              <div class="image-box">
                <div class="image">
                  <a href="news-details.php">
                    <img src="images/resource/blog1-1.jpg" alt="blog">
                    <img src="images/resource/blog1-1.jpg" alt="blog">
                  </a>
                </div>
              </div>
              <div class="content-box">
                <div class="post-meta">
                  <div class="category">Moving</div>
                  <div class="date">20 Dec, 2025</div>
                </div>
                <div class="h4 title"><a href="news-details.php">How to Pack Fragile Items the Right Way</a></div>
                <a class="btn-read-more" href="news-details.php"><i class="fa-regular fa-arrow-right"></i> Read More </a>
              </div>
            </div>
          </div>
          <div class="blog-block col-xl-4 col-md-6">
            <div class="inner-block">
              <div class="image-box">
                <div class="image">
                  <a href="news-details.php">
                    <img src="images/resource/blog1-2.jpg" alt="blog">
                    <img src="images/resource/blog1-2.jpg" alt="blog">
                  </a>
                </div>
              </div>
              <div class="content-box">
                <div class="post-meta">
                  <div class="category">Moving</div>
                  <div class="date">20 Dec, 2025</div>
                </div>
                <div class="h4 title"><a href="news-details.php">The Ultimate Checklist Before You Move</a></div>
                <a class="btn-read-more" href="news-details.php"><i class="fa-regular fa-arrow-right"></i> Read More </a>
              </div>
            </div>
          </div>
          <div class="blog-block col-xl-4 col-md-6">
            <div class="inner-block">
              <div class="image-box">
                <div class="image">
                  <a href="news-details.php">
                    <img src="images/resource/blog1-3.jpg" alt="blog">
                    <img src="images/resource/blog1-3.jpg" alt="blog">
                  </a>
                </div>
              </div>
              <div class="content-box">
                <div class="post-meta">
                  <div class="category">Moving</div>
                  <div class="date">20 Dec, 2025</div>
                </div>
                <div class="h4 title"><a href="news-details.php">The Best Packing Materials for Safe Moving</a></div>
                <a class="btn-read-more" href="news-details.php"><i class="fa-regular fa-arrow-right"></i> Read More </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- end blog-section -->
<!-- Main Footer -->
    <footer class="main-footer footer-style-two">
      <div class="outer-box">
        <div class="shape-1"><img src="images/icons/shape-6.png" alt=""></div>
        <div class="shape-2"><img src="images/icons/footer2-1.png" alt=""></div>
        <div class="shape-3"><img src="images/icons/footer2-2.png" alt=""></div>
        <div class="auto-container">
          <!-- Widgets Section -->
          <div class="widgets-section">
            <div class="row gx-4">
              <!-- Footer Column -->
              <div class="footer-column col-xl-4 col-md-6">
                <div class="footer-widget about-widget">
                  <div class="logo"><img src="images/logo2.png" alt=""></div>
                  <div class="content">
                    <div class="text">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas</div>
                  </div>
                  <div class="info-box">
                    <div class="info">
                      <span><i class="fa-solid fa-phone-flip"></i>Any Help?</span>
                      <div class="h5">+1 (234) 568 000</div>
                    </div>
                    <div class="info">
                      <span><i class="fa-regular fa-envelope"></i>Email Us</span>
                      <div class="h5">support@gmail.com</div>
                    </div>
                  </div>
                </div>
              </div>
              <!-- Footer Column -->
              <div class="footer-column col-xl-2 col-md-6">
                <div class="footer-widget links-widget">
                  <div class="h5 widget-title">Company</div>
                  <div class="widget-content">
                    <ul class="user-links">
                      <li><a href="#/">About</a></li>
                      <li><a href="#/">Our Mission</a></li>
                      <li><a href="#/">Our Blogs</a></li>
                      <li><a href="#/">Help Center</a></li>
                      <li><a href="#/">Contact Us</a></li>
                    </ul>
                  </div>
                </div>
              </div>
              <!-- Footer Column -->
              <div class="footer-column col-xl-2 col-md-6">
                <div class="footer-widget links-widget style-two">
                  <div class="h5 widget-title">Service</div>
                  <div class="widget-content">
                    <ul class="user-links">
                      <li><a href="#/">Long-Distance Moving</a></li>
                      <li><a href="#/">Packing & Unpacking</a></li>
                      <li><a href="#/">Furniture Assembly</a></li>
                      <li><a href="#/">Residential Moving</a></li>
                      <li><a href="#/">Local Moving</a></li>
                    </ul>
                  </div>
                </div>
              </div>
              <!-- Footer Column -->
              <div class="footer-column col-xl-4 col-md-6">
                <div class="footer-widget subscribe-widget">
                  <div class="h5 widget-title">Newsletter</div>
                  <div class="text">Signup for our latest news & articles</div>
                  <div class="form-clt">
                    <input type="email" placeholder="Enter your email" required="">
                    <button class="theme-btn btn-style-five" type="submit">Subscribe</button>
                  </div>
                  <form class="check-box">
                    <input type="checkbox" id="agree" name="agree" value="agree">
                    <label for="agree"> Agree to the <a href="index.php">Privacy Policy.</a></label>
                  </form>
                </div>
              </div>
            </div>
          </div>
          <div class="footer-bottom">
            <div class="inner-container">
              <p class="copyright-text">Copyright © 2026 Movingza . All Rights Reserved.</p>
            </div>
          </div>
          <div class="style-text-box"><div class="h1 style-text">Movingza</div></div>
        </div>
      </div>
    </footer>
    <!--End Main Footer -->

  </div>
<!-- End Page Wrapper -->

<script src="js/jquery.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/wow.js"></script>
<script src="js/select2.min.js"></script>
<script src="js/appear.js"></script>
<script src="js/bxslider.js"></script>
<script src="js/mixitup.js"></script>
<script src="js/knob.js"></script>
<script src="js/swiper.min.js"></script>
<script src="js/aos.js"></script>
<script src="js/gsap.min.js"></script>
<script src="js/ScrollTrigger.min.js"></script>
<script src="js/splitType.js"></script>
<script src="js/gsap-scroll-smoother.js"></script>
<script src="js/gsap-scroll-to-plugin.js"></script>
<script src="js/SplitText.min.js"></script>
<script src="js/custom-gsap.js"></script>
<script src="js/script.js"></script>
<!-- form submit -->
<script src="js/jquery.validate.min.js"></script>
<script src="js/jquery.form.min.js"></script>
<script src="js/contact-form-script.js"></script>
</body>
</html>
