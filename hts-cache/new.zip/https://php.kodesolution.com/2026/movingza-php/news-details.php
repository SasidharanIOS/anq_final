<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Movingza - Movers & Packers PHP Template - Blog Details</title>
  <link href="css/bootstrap.min.css" rel="stylesheet" />
  <link href="css/style.css" rel="stylesheet" />
  <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon" />
  <link rel="icon" href="images/favicon.png" type="image/x-icon" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>
<body>
<div class="page-wrapper">

    <div class="preloader"></div>

    <!-- Back-to-top start -->
    <div class="back-to-top-wrapper">
      <button id="back_to_top" type="button" class="back-to-top-btn">
        <svg width="12" height="7" viewBox="0 0 12 7" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M11 6L6 1L1 6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
        </svg>
      </button>
    </div>
    <!-- Back-to-top start -->

    <!-- Main Header-->
    <header class="main-header header-style-one">
      <div class="outer-box">
        <div class="header-lower anim-fade-move" data-delay="0.25">
          <div class="inner-container">
            <!-- Main box -->
            <div class="main-box">
              <div class="logo-box">
                <div class="logo">
                  <a href="index.php"><img src="images/logo.png" alt="Logo" /></a>
                </div>
              </div>

            </div>
            <!--Nav Box-->
            <div class="nav-outer">
              <nav class="nav main-menu">
                <ul class="navigation">
  <li class="dropdown">
    <a href="index.php">Home</a>
    <ul>
      <li><a href="index.php">Home 01</a></li>
      <li><a href="index-2.php">Home 02</a></li>
      <li><a href="index-3.php">Home 03</a></li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">Pages</a>
    <ul>
      <li><a href="page-about.php">About Us</a></li>
      <li class="dropdown"><a href="#">Team</a>
        <ul>
          <li><a href="page-team.php">Team Grid</a></li>
          <li><a href="page-team-details.php">Team Details</a></li>
        </ul>
      </li>
      <li><a href="page-pricing.php">Pricing Plan</a></li>
      <li><a href="page-testimonial.php">Testimonials</a></li>
      <li><a href="page-faq.php">Faq</a></li>
      <li class="dropdown"><a href="#">Shop</a>
        <ul>
          <li><a href="shop-products.php">Products</a></li>
          <li><a href="shop-products-sidebar.php">Products with Sidebar</a></li>
          <li><a href="shop-product-details.php">Product Details</a></li>
          <li><a href="shop-cart.php">Cart</a></li>
          <li><a href="shop-checkout.php">Checkout</a></li>
        </ul>
      </li>
      <li><a href="page-404.php">404</a></li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">Services</a>
    <ul>
      <li><a href="page-services.php">Services Grid</a></li>
      <li><a href="page-service-details.php">Services Details</a></li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">Projects</a>
    <ul>
      <li><a href="page-projects.php">Project Grid</a></li>
      <li><a href="page-project-details.php">Project Details</a></li>
    </ul>
  </li>
  <li class="current dropdown"><a href="#">Blog</a>
    <ul>
      <li><a href="news-grid.php">Blog Grid</a></li>
      <li><a href="news-details.php">Blog Details</a></li>
    </ul>
  </li>
  <li class=""><a href="page-contact.php">Contact</a></li>
</ul>
              </nav>
            </div>
            <div class="right-box">
              <button class="ui-btn search-btn">
                <i class="fa-solid fa-magnifying-glass"></i>
              </button>
              <a class="theme-btn btn-style-five" href="page-contact.php">
                <span class="btn-title">Get Appointment </span>
              </a>
              <!--Mobile Navigation Toggler-->
              <div class="mobile-nav-toggler">
                <span></span>
                <span></span>
                <span></span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Mobile Menu  -->
      <div class="mobile-menu">
        <div class="menu-backdrop"></div>
        <!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
        <nav class="menu-box">
          <div class="upper-box">
            <div class="nav-logo">
              <a href="index.php"><img src="images/logo2.png" alt="" /></a>
            </div>
            <div class="close-btn"><i class="icon fa fa-times"></i></div>
          </div>
          <ul class="navigation clearfix">
            <!--Keep This Empty / Menu will come through Javascript-->
          </ul>
          <ul class="contact-list-one">
            <li>
              <i class="icon fa-regular fa-envelope"></i>
              <span class="title">Send Email</span>
              <div class="text"><a href="mailto:needhelp@company.com">needhelp@company.com</a></div>
            </li>
          </ul>
          <ul class="social-links">
            <li>
              <a href="#"><i class="icon fab fa-twitter"></i></a>
            </li>
            <li>
              <a href="#"><i class="icon fab fa-facebook-f"></i></a>
            </li>
            <li>
              <a href="#"><i class="icon fab fa-pinterest-p"></i></a>
            </li>
            <li>
              <a href="#"><i class="icon fab fa-vimeo-v"></i></a>
            </li>
          </ul>
        </nav>
      </div>
      <!-- End Mobile Menu -->

      <!-- Header Search -->
      <div class="search-popup">
        <span class="search-back-drop"></span>
        <button class="close-search"><span class="fa fa-times"></span></button>

        <div class="search-inner">
          <form method="post" action="index.php">
            <div class="form-group">
              <input type="search" name="search-field" value="" placeholder="Search..." required="" />
              <button type="submit"><i class="fa fa-search"></i></button>
            </div>
          </form>
        </div>
      </div>
      <!-- End Header Search -->

      <!-- Sticky Header  -->
      <div class="sticky-header">
        <div class="auto-container">
          <div class="inner-container">
            <!--Logo-->
            <div class="logo">
              <a href="index.php"><img src="images/logo.png" alt=""></a>
            </div>

            <!--Right Col-->
            <div class="nav-outer">
              <!-- Main Menu -->
              <nav class="main-menu">
                <div class="navbar-collapse show collapse clearfix">
                  <ul class="navigation clearfix">
                    <!--Keep This Empty / Menu will come through Javascript-->
                  </ul>
                </div>
              </nav>
              <!-- Main Menu End-->

              <!--Mobile Navigation Toggler-->
              <div class="mobile-nav-toggler">
                <span></span>
                <span></span>
                <span></span>
              </div>
            </div>
            
            <a href="tel:+8801750050088" class="header-phone_box">
              <span class="icon"><i aria-hidden="true" class="fas fa-phone-alt"></i></span>
              <span class="info">
                Call Anytime
                <strong>+8801750050088</strong>
              </span>
            </a>
          </div>
        </div>
      </div>
      <!-- End Sticky Menu -->
    </header>
    <!--End Main Header -->
<!-- Start main-content -->
    <section class="page-title" style="background-image: url(images/resource/page-title.png);opacity: 0.85;background-color: var(--theme-color-lighter);">
      <div class="auto-container">
        <div class="title-outer text-center">
          <div class="h1 title">Blog Details</div>
          <ul class="page-breadcrumb">
            <li><a href="index.php">Home</a></li>
            <li>Blog Details</li>
          </ul>
        </div>
      </div>
    </section>
    <!-- end main-content -->
<!--Blog Details Start-->
    <section class="blog-details pt-120 pb-120">
      <div class="container">
        <div class="row">
          <div class="col-xl-8 col-lg-7">
            <div class="blog-details__left">
              <div class="blog-details__img">
                <img src="images/resource/news-details.jpg" alt="">
                <div class="blog-details__date">
                  <span class="day">28</span>
                  <span class="month">Aug</span>
                </div>
              </div>
              <div class="blog-details__content">
                <ul class="list-unstyled blog-details__meta">
                  <li><a href="news-details.php"><i class="fas fa-user-circle"></i> Admin</a> </li>
                  <li><a href="news-details.php"><i class="fas fa-comments"></i> 02 Comments</a></li>
                </ul>
                <div class="h3 blog-details__title">How to Pack Fragile Items Without Damage</div>
                <p class="blog-details__text-2">Mauris non dignissim purus, ac commodo diam. Donec sit amet lacinia nulla. Aliquam quis purus in justo pulvinar tempor. Aliquam tellus nulla, sollicitudin at euismod nec, feugiat at nisi. Quisque vitae odio nec lacus interdum tempus. Phasellus a rhoncus erat. Vivamus vel eros vitae est aliquet pellentesque vitae et nunc. Sed vitae leo vitae nisl pellentesque semper.</p>
                <p class="blog-details__text-2">Mauris non dignissim purus, ac commodo diam. Donec sit amet lacinia nulla. Aliquam quis purus in justo pulvinar tempor. Aliquam tellus nulla, sollicitudin at euismod nec, feugiat at nisi. Quisque vitae odio nec lacus interdum tempus. Phasellus a rhoncus erat. Vivamus vel eros vitae est aliquet pellentesque vitae et nunc. Sed vitae leo vitae nisl pellentesque semper.</p>
                <p class="blog-details__text-2">Mauris non dignissim purus, ac commodo diam. Donec sit amet lacinia nulla. Aliquam quis purus in justo pulvinar tempor. Aliquam tellus nulla, sollicitudin at euismod nec, feugiat at nisi. Quisque vitae odio nec lacus interdum tempus. Phasellus a rhoncus erat. Vivamus vel eros vitae est aliquet pellentesque vitae et nunc. Sed vitae leo vitae nisl pellentesque semper.</p>
              </div>
              <div class="blog-details__bottom">
                <p class="blog-details__tags"> <span>Tags</span> <a href="news-details.php">Business</a> <a href="news-details.php">Agency</a> </p>
                <div class="blog-details__social-list"> <a href="news-details.php"><i class="fab fa-twitter"></i></a> <a href="news-details.php"><i class="fab fa-facebook"></i></a> <a href="news-details.php"><i class="fab fa-pinterest-p"></i></a> <a href="news-details.php"><i class="fab fa-instagram"></i></a> </div>
              </div>
              <div class="nav-links">
                <div class="prev">
                  <a href="news-details.php" rel="prev">Bring to the table win-win survival strategies</a>
                </div>
                <div class="next">
                  <a href="news-details.php" rel="next">How to lead a healthy &amp; well-balanced life</a>
                </div>
              </div>
              <div class="comment-one">
                <div class="h3 comment-one__title">2 Comments</div>
                <div class="comment-one__single">
                  <div class="comment-one__image"> <img src="images/resource/client-3.jpg" alt=""> </div>
                  <div class="comment-one__content">
                    <div class="h3">Kevin Martin</div>
                    <p>Mauris non dignissim purus, ac commodo diam. Donec sit amet lacinia nulla. Aliquam quis purus in justo pulvinar tempor. Aliquam tellus nulla, sollicitudin at euismod.</p>
                    <a href="news-details.php" class="theme-btn btn-style-four comment-one__btn"><span class="btn-title">Reply</span></a>
                  </div>
                </div>
                <div class="comment-one__single">
                  <div class="comment-one__image"> <img src="images/resource/client-2.jpg" alt=""> </div>
                  <div class="comment-one__content">
                    <div class="h3">Sarah Albert</div>
                    <p>Mauris non dignissim purus, ac commodo diam. Donec sit amet lacinia nulla. Aliquam quis purus in justo pulvinar tempor. Aliquam tellus nulla, sollicitudin at euismod.</p>
                    <a href="news-details.php" class="theme-btn btn-style-four comment-one__btn"><span class="btn-title">Reply</span></a>
                  </div>
                </div>
                <div class="comment-form">
                  <div class="h3 comment-form__title">Leave a Comment</div>
                  <form id="contact_form" name="contact_form" class="" action="includes/sendmail.php" method="post">
                    <input type="hidden" name="csrf_token" value="0bb39212a4a62f12ee834040b36986d6bb064ff715f907bde77aaa99cec2073a">                    <div class="row">
                      <div class="col-sm-6">
                        <div class="mb-3">
                          <input name="form_name" class="form-control" type="text" placeholder="Enter Name">
                        </div>
                      </div>
                      <div class="col-sm-6">
                        <div class="mb-3">
                          <input name="form_email" class="form-control required email" type="email" placeholder="Enter Email">
                        </div>
                      </div>
                    </div>
                    <div class="mb-3">
                      <textarea name="form_message" class="form-control required" rows="5" placeholder="Enter Message"></textarea>
                    </div>
                    <div class="mb-3">
                      <input name="form_botcheck" class="form-control" type="hidden" value="" />
                      <button type="submit" class="theme-btn btn-style-four" data-loading-text="Please wait..."><span class="btn-title">Submit Comment</span></button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
          <div class="col-xl-4 col-lg-5">
            <div class="sidebar">
              <div class="sidebar__single sidebar__search">
                <form action="#" class="sidebar__search-form">
                  <input type="search" placeholder="Search here">
                  <button type="submit"><i class="lnr-icon-search"></i></button>
                </form>
              </div>
              <div class="sidebar__single sidebar__post">
                <div class="h3 sidebar__title">Latest Posts</div>
                <ul class="sidebar__post-list list-unstyled">
                  <li>
                    <div class="sidebar__post-image"> <img src="images/resource/blog1-1.jpg" alt=""> </div>
                    <div class="sidebar__post-content">
                      <div class="h3"> <span class="sidebar__post-content-meta"><i class="fas fa-user-circle"></i>Admin</span> <a href="news-details.php">Packing Hacks That Save Time and Money</a>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="sidebar__post-image"> <img src="images/resource/blog1-2.jpg" alt=""> </div>
                    <div class="sidebar__post-content">
                      <div class="h3"> <span class="sidebar__post-content-meta"><i class="fas fa-user-circle"></i>Admin</span> <a href="news-details.php">How to Move Your Office Without Downtime</a> </div>
                    </div>
                  </li>
                  <li>
                    <div class="sidebar__post-image"> <img src="images/resource/blog1-3.jpg" alt=""> </div>
                    <div class="sidebar__post-content">
                      <div class="h3"> <span class="sidebar__post-content-meta"><i class="fas fa-user-circle"></i>Admin</span> <a href="news-details.php">Safe Storage Solutions During Relocation</a> </div>
                    </div>
                  </li>
                </ul>
              </div>
              <div class="sidebar__single sidebar__category">
                <div class="h3 sidebar__title">Categories</div>
                <ul class="sidebar__category-list list-unstyled">
                  <li><a href="news-details.php">Moving Tips<span class="lnr-icon-arrow-right"></span></a> </li>
                  <li class="active"><a href="news-details.php">Packing Guides<span class="lnr-icon-arrow-right"></span></a></li>
                  <li><a href="news-details.php">Relocation Services<span class="lnr-icon-arrow-right"></span></a> </li>
                  <li><a href="news-details.php">Cost & Budgeting<span class="lnr-icon-arrow-right"></span></a> </li>
                  <li><a href="news-details.php">Safety & Insurance<span class="lnr-icon-arrow-right"></span></a> </li>
                  <li><a href="news-details.php">Case Studies<span class="lnr-icon-arrow-right"></span></a> </li>
                </ul>
              </div>
              <div class="sidebar__single sidebar__tags">
                <div class="h3 sidebar__title">Tags</div>
                <div class="sidebar__tags-list">
                  <a href="#">Packing</a>
                  <a href="#">Moving</a>
                  <a href="#">Logistics</a>
                  <a href="#">Storage</a>
                  <a href="#">Fragile</a>
                  <a href="#">Relocation</a>
                </div>
              </div>
              <div class="sidebar__single sidebar__comments">
                <div class="h3 sidebar__title">Recent Comments</div>
                <ul class="sidebar__comments-list list-unstyled">
                  <li>
                    <div class="sidebar__comments-icon"><i class="fas fa-comments"></i> </div>
                    <div class="sidebar__comments-text-box">
                      <p>A wordpress commenter on <br />launch new mobile app</p>
                    </div>
                  </li>
                  <li>
                    <div class="sidebar__comments-icon"><i class="fas fa-comments"></i> </div>
                    <div class="sidebar__comments-text-box">
                      <p><span>John Doe</span> on template:</p>
                      <div class="h5">comments</div>
                    </div>
                  </li>
                  <li>
                    <div class="sidebar__comments-icon"><i class="fas fa-comments"></i> </div>
                    <div class="sidebar__comments-text-box">
                      <p>A wordpress commenter on <br />launch new mobile app</p>
                    </div>
                  </li>
                  <li>
                    <div class="sidebar__comments-icon"><i class="fas fa-comments"></i> </div>
                    <div class="sidebar__comments-text-box">
                      <p><span>John Doe</span> on template:</p>
                      <div class="h5">comments</div>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--Blog Details End-->
<!-- Main Footer -->
    <footer class="main-footer footer-style-one">
      <div class="auto-container">
        <div class="style-text-box"><div class="h1 style-text">Movingza</div></div>
        <!-- Widgets Section -->
        <div class="widgets-section">
          <div class="row gx-4">
            <!-- Footer Column -->
            <div class="footer-column col-lg-4 col-md-6">
              <div class="footer-widget subscribe-widget">
                <div class="h3 widget-title">Subscribe to Our Newsletter</div>
                <div class="form-clt">
                  <input type="email" placeholder="Enter email" required="" >
                  <button class="theme-btn btn-style-five" type="submit">Subscribe</button>
                </div>
                <form class="check-box">
                  <input type="checkbox" id="agree" name="agree" value="agree">
                  <label for="agree"> I agree to the <a href="index.php">privacy policy.</a></label>
                </form>
              </div>
            </div>
            <!-- Footer Column -->
            <div class="footer-column col-lg-2 col-md-6">
              <div class="footer-widget links-widget">
                <div class="h5 widget-title">Company</div>
                <div class="widget-content">
                  <ul class="user-links">
                    <li><a href="#/">About</a></li>
                    <li><a href="#/">Our Mission</a></li>
                    <li><a href="#/">Our Blogs</a></li>
                    <li><a href="#/">Help Center</a></li>
                    <li><a href="#/">Contact Us</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <!-- Footer Column -->
            <div class="footer-column col-lg-3 col-md-6">
              <div class="footer-widget links-widget style-two">
                <div class="h5 widget-title">Service</div>
                <div class="widget-content">
                  <ul class="user-links">
                    <li><a href="#/">Residential Moving</a></li>
                    <li><a href="#/">Furniture Assembly</a></li>
                    <li><a href="#/">Local Moving</a></li>
                    <li><a href="#/">Long-Distance Moving</a></li>
                    <li><a href="#/">Packing & Unpacking</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <!-- Footer Column -->
            <div class="footer-column style-two col-lg-3 col-md-6">
              <div class="footer-widget contact-widget">
                <div class="widget-content">
                  <ul class="social-info style-one">
                    <li>+629 555-0129</li>
                    <li>demo@example.com</li>
                  </ul>
                  <ul class="social-info">
                    <li>1901 Thornridge Cir. Shiloh <br>Hawaii 81063</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="footer-bottom">
          <div class="inner-container">
            <div class="upper-box">
              <div class="logo"><img src="images/logo3.png" alt=""></div>
              <ul class="footer-nav">
                <li><a href="#">Terms & Condition</a></li>
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">Contact us</a></li>
              </ul>
            </div>
            <div class="lower-box">
              <p class="copyright-text">© Copyright 2026 by Company.com | All Rights Reserved</p>
              <ul class="social-icon">
                <li>
                  <a href="#"><i class="fa-brands fa-facebook-f"></i></a>
                </li>
                <li>
                  <a href="#"><i class="fa-brands fa-twitter"></i></a>
                </li>
                <li>
                  <a href="#"><i class="fa-brands fa-linkedin-in"></i></a>
                </li>
                <li>
                  <a href="#"><i class="fa-brands fa-youtube"></i></a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </footer>
    <!--End Main Footer -->

  </div>
<!-- End Page Wrapper -->

<script src="js/jquery.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/wow.js"></script>
<script src="js/select2.min.js"></script>
<script src="js/appear.js"></script>
<script src="js/bxslider.js"></script>
<script src="js/mixitup.js"></script>
<script src="js/knob.js"></script>
<script src="js/swiper.min.js"></script>
<script src="js/aos.js"></script>
<script src="js/gsap.min.js"></script>
<script src="js/ScrollTrigger.min.js"></script>
<script src="js/splitType.js"></script>
<script src="js/gsap-scroll-smoother.js"></script>
<script src="js/gsap-scroll-to-plugin.js"></script>
<script src="js/SplitText.min.js"></script>
<script src="js/custom-gsap.js"></script>
<script src="js/script.js"></script>
<!-- form submit -->
<script src="js/jquery.validate.min.js"></script>
<script src="js/jquery.form.min.js"></script>
<script src="js/contact-form-script.js"></script>
</body>
</html>
